"""Candidate generation: dictionaries, mutations, brute force and masks."""

from __future__ import annotations

import itertools
import re
import string
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Iterator, Optional

MAX_PASSWORD_CHARS = 256
MAX_PASSWORD_BYTES = 127


def _clip(value: str) -> str:
    if len(value) > MAX_PASSWORD_CHARS:
        value = value[:MAX_PASSWORD_CHARS]
    encoded = value.encode("utf-8", "ignore")
    if len(encoded) > MAX_PASSWORD_BYTES:
        value = encoded[:MAX_PASSWORD_BYTES].decode("utf-8", "ignore")
    return value


def wordlist_lines(path: str | Path) -> Iterator[str]:
    """Yield passwords from a wordlist, preserving leading/trailing spaces."""
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        for raw in fh:
            line = raw.rstrip("\r\n")
            if line:
                yield _clip(line)


def count_wordlist_lines(path: str | Path) -> int:
    total = 0
    with open(path, "rb") as fh:
        for _ in fh:
            total += 1
    return total


LEET_MAP = str.maketrans({"a": "@", "e": "3", "i": "1", "o": "0", "s": "$", "t": "7"})
LEET_MAP_FULL = str.maketrans(
    {"a": "4", "e": "3", "i": "1", "o": "0", "s": "5", "t": "7", "g": "9", "b": "8"}
)

LIGHT_SUFFIXES = (
    "!",
    "@",
    "#",
    "1!",
    "12",
    "123",
    "1234",
    "12345",
    "007",
    "2024",
    "2025",
    "2026",
)


def _light_variants(word: str) -> Iterator[str]:
    seen: set[str] = set()

    def emit(value: str) -> Iterator[str]:
        value = _clip(value)
        if value and value not in seen:
            seen.add(value)
            yield value

    yield from emit(word)
    yield from emit(word.lower())
    yield from emit(word.upper())
    yield from emit(word.capitalize())
    yield from emit(word.title())
    for digit in string.digits:
        yield from emit(word + digit)
    for suffix in LIGHT_SUFFIXES:
        yield from emit(word + suffix)


def _medium_variants(word: str) -> Iterator[str]:
    seen: set[str] = set()

    def emit(value: str) -> Iterator[str]:
        value = _clip(value)
        if value and value not in seen:
            seen.add(value)
            yield value

    yield from emit(word)
    yield from emit(word.lower())
    yield from emit(word.upper())
    yield from emit(word.capitalize())
    yield from emit(word.title())
    yield from emit(word[::-1])
    yield from emit(word.translate(LEET_MAP))
    yield from emit(word.translate(LEET_MAP_FULL))
    yield from emit(word.translate(LEET_MAP).capitalize())
    for digit in string.digits:
        yield from emit(word + digit)
    for number in range(100):
        yield from emit(f"{word}{number:02d}")
    for year in range(1980, 2027):
        yield from emit(f"{word}{year}")
    for suffix in LIGHT_SUFFIXES:
        yield from emit(word + suffix)
    for suffix in ("!!", "123!", "2024!"):
        yield from emit(word + suffix)


def apply_rules(word: str, level: str) -> Iterator[str]:
    if level == "medium":
        yield from _medium_variants(word)
    elif level == "light":
        yield from _light_variants(word)
    else:
        value = _clip(word)
        if value:
            yield value


def filename_candidates(filename: str) -> Iterator[str]:
    stem = Path(filename).stem
    if not stem:
        return
    seen: set[str] = set()

    def emit(value: str) -> Iterator[str]:
        value = _clip(value)
        if value and value.lower() not in seen:
            seen.add(value.lower())
            yield value

    yield from emit(stem)
    parts = [p for p in re.split(r"[^A-Za-z0-9]+", stem) if p]
    if len(parts) > 1:
        joined = "".join(parts)
        yield from emit(joined)
        yield from emit(joined.lower())
        yield from emit(joined.capitalize())
        for part in parts:
            if len(part) >= 2:
                yield from emit(part)
                yield from emit(part.capitalize())
                yield from emit(part.upper())
    for number in re.findall(r"\d{2,4}", stem):
        yield from emit(number)


# ---------------------------------------------------------------------------
# Plans
# ---------------------------------------------------------------------------
class CandidatePlan:
    mode = "candidates"

    def estimate(self) -> Optional[int]:
        return None

    def candidates(self) -> Iterator[str]:
        raise NotImplementedError

    def describe(self) -> str:
        return self.mode


@dataclass
class DictionaryPlan(CandidatePlan):
    wordlists: list[str] = field(default_factory=list)
    rules: str = "light"
    include_filename: bool = True
    filename: str = ""
    mode = "dictionary"

    def estimate(self) -> Optional[int]:
        multiplier = {"none": 1, "light": 29, "medium": 190}.get(self.rules, 1)
        total = 0
        for path in self.wordlists:
            try:
                total += count_wordlist_lines(path) * multiplier
            except OSError:
                continue
        if self.include_filename:
            total += 30
        return total

    def candidates(self) -> Iterator[str]:
        if self.include_filename and self.filename:
            for value in filename_candidates(self.filename):
                yield value
                if self.rules != "none":
                    for variant in apply_rules(value, self.rules):
                        if variant != value:
                            yield variant
        for path in self.wordlists:
            try:
                for word in wordlist_lines(path):
                    yield from apply_rules(word, self.rules)
            except OSError:
                continue

    def describe(self) -> str:
        return f"Dictionary · {len(self.wordlists)} list(s) · {self.rules} rules"


@dataclass
class BrutePlan(CandidatePlan):
    chars: str = string.ascii_lowercase + string.digits
    min_length: int = 1
    max_length: int = 6
    mode = "brute"

    def estimate(self) -> Optional[int]:
        n = len(self.chars)
        if n == 0:
            return 0
        return sum(n**k for k in range(self.min_length, self.max_length + 1))

    def candidates(self) -> Iterator[str]:
        alphabet = "".join(dict.fromkeys(self.chars))
        for length in range(self.min_length, self.max_length + 1):
            for combo in itertools.product(alphabet, repeat=length):
                yield "".join(combo)

    def describe(self) -> str:
        return f"Brute force · {len(self.chars)} chars · length {self.min_length}-{self.max_length}"


DEFAULT_MASK_SETS = {
    "l": string.ascii_lowercase,
    "u": string.ascii_uppercase,
    "d": string.digits,
    "s": string.punctuation,
    "a": string.ascii_letters + string.digits + string.punctuation + " ",
    "h": "0123456789abcdef",
    "H": "0123456789ABCDEF",
}


def parse_custom_sets(spec: str) -> dict[str, str]:
    """Parse ``1=abc;2=XYZ`` into a token map."""
    result: dict[str, str] = {}
    for chunk in re.split(r"[;\n]+", spec):
        chunk = chunk.strip()
        if not chunk:
            continue
        match = re.match(r"^([1-9])\s*=\s*(.+)$", chunk)
        if not match:
            raise ValueError(f"Invalid custom set: {chunk!r} (use 1=abc;2=XYZ)")
        result[match.group(1)] = match.group(2)
    return result


def parse_mask(pattern: str, custom: Optional[dict[str, str]] = None) -> list[str]:
    """Expand a mask such as ``?u?l?l?l?d?d`` into per-position alphabets."""
    custom = custom or {}
    groups: list[str] = []
    i = 0
    while i < len(pattern):
        ch = pattern[i]
        if ch == "\\":
            if i + 1 >= len(pattern):
                raise ValueError("Mask ends with a dangling backslash.")
            groups.append(pattern[i + 1])
            i += 2
            continue
        if ch != "?":
            groups.append(ch)
            i += 1
            continue
        if i + 1 >= len(pattern):
            raise ValueError("Mask ends with a dangling '?'.")
        token = pattern[i + 1]
        i += 2
        if token == "?":
            groups.append("?")
        elif token in DEFAULT_MASK_SETS:
            groups.append(DEFAULT_MASK_SETS[token])
        elif token in custom:
            groups.append(custom[token])
        else:
            raise ValueError(
                f"Unknown mask token '?{token}'. Use ?l ?u ?d ?s ?a ?h ?H, ?1-?9, or ?? for a literal ?."
            )
    if not groups:
        raise ValueError("The mask is empty.")
    return groups


@dataclass
class MaskPlan(CandidatePlan):
    pattern: str = "?u?l?l?l?d?d?d?d"
    custom_sets: dict[str, str] = field(default_factory=dict)
    mode = "mask"

    def groups(self) -> list[str]:
        return parse_mask(self.pattern, self.custom_sets)

    def estimate(self) -> Optional[int]:
        groups = self.groups()
        total = 1
        for group in groups:
            total *= len(group)
        return total

    def candidates(self) -> Iterator[str]:
        groups = self.groups()
        for combo in itertools.product(*groups):
            yield "".join(combo)

    def describe(self) -> str:
        return f"Mask · {self.pattern}"
