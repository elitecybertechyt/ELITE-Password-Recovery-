"""Generate local password-protected fixtures used by ELITE Password Recovery tests."""
from __future__ import annotations

import os
import zipfile
from pathlib import Path

import py7zr
import pyzipper
from pypdf import PdfWriter

ROOT = Path(__file__).resolve().parent.parent
SAMPLES = ROOT / "samples"
SAMPLES.mkdir(exist_ok=True)


def make_pdf(name: str, algorithm: str, user: str = "secret123", owner: str = "ownerpass") -> Path:
    path = SAMPLES / name
    writer = PdfWriter()
    writer.add_blank_page(width=612, height=792)
    writer.add_metadata({"/Title": "ELITE Password Recovery test document", "/Author": "Local fixture"})
    writer.encrypt(user_password=user, owner_password=owner, algorithm=algorithm)
    with path.open("wb") as fh:
        writer.write(fh)
    return path


def make_zip(name: str, password: str = "secret123", aes: bool = True) -> Path:
    path = SAMPLES / name
    payload = (b"ELITE Password Recovery ZIP fixture\n" * 40)
    if aes:
        with pyzipper.AESZipFile(
            path,
            "w",
            compression=pyzipper.ZIP_DEFLATED,
            encryption=pyzipper.WZ_AES,
        ) as zf:
            zf.setpassword(password.encode())
            zf.writestr("notes/readme.txt", payload)
            zf.writestr("blank.bin", b"x")
    else:
        # Python's zipfile cannot write ZipCrypto; this fixture is produced by
        # tools/make_zipcrypto.py.
        pass
    return path


def make_7z(name: str, password: str = "secret123", encrypt_headers: bool = True) -> Path:
    path = SAMPLES / name
    with py7zr.SevenZipFile(
        path,
        "w",
        password=password,
        header_encryption=encrypt_headers,
    ) as zf:
        zf.writestr(b"ELITE Password Recovery 7z fixture\n" * 40, "notes/readme.txt")
    return path


def main() -> None:
    for alg, fname in [
        ("RC4-40", "sample_rc4_40.pdf"),
        ("RC4-128", "sample_rc4_128.pdf"),
        ("AES-128", "sample_aes128.pdf"),
        ("AES-256-R5", "sample_aes256_r5.pdf"),
        ("AES-256", "sample_aes256_r6.pdf"),
    ]:
        print(make_pdf(fname, alg))
    print(make_zip("sample_aes.zip", aes=True))
    print(make_7z("sample_header.7z", encrypt_headers=True))
    print(make_7z("sample_data.7z", encrypt_headers=False))


if __name__ == "__main__":
    main()
