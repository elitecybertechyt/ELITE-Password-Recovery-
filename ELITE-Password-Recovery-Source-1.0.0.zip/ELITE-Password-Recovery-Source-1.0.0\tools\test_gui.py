from __future__ import annotations

import multiprocessing
import sys
import tkinter as tk
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from elite_recovery.gui import EliteApp  # noqa: E402


def main() -> int:
    target = sys.argv[1] if len(sys.argv) > 1 else "samples/sample_aes256_r6.pdf"
    wordlist = sys.argv[2] if len(sys.argv) > 2 else "samples/test_words.txt"
    expected = sys.argv[3] if len(sys.argv) > 3 else "secret123"

    root = tk.Tk()
    app = EliteApp(root, initial_file=str(ROOT / target))
    state = {"started": False, "done": False}

    def begin() -> None:
        if not app.report or not app.report.supported:
            root.after(200, begin)
            return
        app.notebook.select(0)
        app.builtin_var.set(False)
        app.wordlist_var.set(str(ROOT / wordlist))
        app.filename_var.set(False)
        app.rules_var.set("Exact words only")
        app.workers_var.set(4)
        app._start()
        state["started"] = True

    def check() -> None:
        result = app._last_result
        if result is not None:
            state["done"] = True
            ok = result.found and result.password == expected
            print(
                f"GUI RESULT found={result.found} password={result.password!r} "
                f"tried={result.tried} reason={result.reason} ok={ok}"
            )
            root.after(200, root.destroy)
            if not ok:
                state["failed"] = True
            return
        root.after(200, check)

    root.after(1800, begin)
    root.after(2200, check)
    root.after(90000, lambda: (print("GUI TIMEOUT"), root.destroy()))
    root.mainloop()
    return 1 if state.get("failed") or not state["done"] else 0


if __name__ == "__main__":
    multiprocessing.freeze_support()
    raise SystemExit(main())
