"""ELITE Password Recovery launcher (GUI)."""

from __future__ import annotations

import argparse
import json
import multiprocessing
import sys
from pathlib import Path

# Make source-tree launches work without installing the package.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from elite_recovery import __version__  # noqa: E402


def main() -> None:
    # Must run before argparse: PyInstaller's multiprocessing bootstrap passes
    # its own internal arguments to the frozen executable.
    multiprocessing.freeze_support()

    parser = argparse.ArgumentParser(
        prog="ELITE Password Recovery",
        description="Local password recovery for PDF, Office, ZIP and 7z documents.",
    )
    parser.add_argument("file", nargs="?", help="document to open on launch")
    parser.add_argument("--version", action="version", version=f"ELITE Password Recovery {__version__}")
    parser.add_argument("--smoke-test", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--selftest", metavar="DOCUMENT", help=argparse.SUPPRESS)
    parser.add_argument("--selftest-wordlist", help=argparse.SUPPRESS)
    parser.add_argument("--selftest-expect", help=argparse.SUPPRESS)
    parser.add_argument("--selftest-out", help=argparse.SUPPRESS)
    args = parser.parse_args()

    if args.selftest:
        if not (args.selftest_wordlist and args.selftest_out):
            parser.error("selftest requires --selftest-wordlist and --selftest-out")
        from elite_recovery.candidates import DictionaryPlan
        from elite_recovery.engine import CrackController

        plan = DictionaryPlan(
            wordlists=[args.selftest_wordlist],
            rules="none",
            include_filename=False,
            filename="",
        )
        holder = {}

        def done(result):
            holder["result"] = result

        controller = CrackController(
            path=args.selftest,
            plan=plan,
            workers=2,
            batch_size=8,
            estimate=plan.estimate(),
            on_done=done,
        )
        controller.start()
        controller.join(timeout=120)
        result = holder.get("result")
        payload = {
            "found": bool(result and result.found),
            "password": result.password if result else None,
            "tried": result.tried if result else 0,
            "reason": result.reason if result else "timeout",
            "ok": bool(result and result.found and result.password == args.selftest_expect),
        }
        Path(args.selftest_out).write_text(json.dumps(payload), encoding="utf-8")
        sys.exit(0 if payload["ok"] else 1)

    from elite_recovery.gui import run

    run(initial_file=args.file, smoke_test=args.smoke_test)


if __name__ == "__main__":
    main()
