param(
    [Parameter(Mandatory = $true)][int]$ProcessId,
    [string]$OutFile = "window.png",
    [switch]$Screen
)

Add-Type -AssemblyName System.Drawing
Add-Type @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public class CaptureHelper {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
    [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int cmd);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    public static IntPtr FindWindow(uint targetPid) {
        IntPtr result = IntPtr.Zero;
        EnumWindows((h, l) => {
            uint pid; GetWindowThreadProcessId(h, out pid);
            if (pid == targetPid && IsWindowVisible(h)) {
                var sb = new StringBuilder(512);
                GetWindowText(h, sb, 512);
                string title = sb.ToString();
                if (title.Contains("ELITE Password Recovery")) { result = h; return false; }
            }
            return true;
        }, IntPtr.Zero);
        return result;
    }
}
'@

$hwnd = [CaptureHelper]::FindWindow([uint32]$ProcessId)
if ($hwnd -eq [IntPtr]::Zero) {
    Write-Error "No ELITE Password Recovery window found for process $ProcessId"
    exit 1
}
[CaptureHelper]::ShowWindow($hwnd, 5) | Out-Null
[CaptureHelper]::SetWindowPos($hwnd, [IntPtr](-1), 0, 0, 0, 0, 0x0043) | Out-Null
[CaptureHelper]::SetForegroundWindow($hwnd) | Out-Null
Start-Sleep -Milliseconds 700

$rect = New-Object CaptureHelper+RECT
[CaptureHelper]::GetWindowRect($hwnd, [ref]$rect) | Out-Null
$width = $rect.Right - $rect.Left
$height = $rect.Bottom - $rect.Top
Write-Output "window $($rect.Left),$($rect.Top) ${width}x${height}"

$bitmap = New-Object System.Drawing.Bitmap($width, $height)
if (-not $Screen) {
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $hdc = $graphics.GetHdc()
    [CaptureHelper]::PrintWindow($hwnd, $hdc, 0) | Out-Null
    $graphics.ReleaseHdc($hdc)
    $graphics.Dispose()

    # Tk sometimes gives PrintWindow a blank surface; fall back to a screen grab.
    $colors = @{}
    for ($x = 0; $x -lt $width; $x += 40) {
        for ($y = 0; $y -lt $height; $y += 40) {
            $colors[$bitmap.GetPixel($x, $y).ToArgb()] = 1
        }
    }
    $Screen = ($colors.Count -lt 4)
}
if ($Screen) {
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, $bitmap.Size)
    $graphics.Dispose()
}
$bitmap.Save((Join-Path (Get-Location) $OutFile), [System.Drawing.Imaging.ImageFormat]::Png)
$bitmap.Dispose()
Write-Output "saved $OutFile"
