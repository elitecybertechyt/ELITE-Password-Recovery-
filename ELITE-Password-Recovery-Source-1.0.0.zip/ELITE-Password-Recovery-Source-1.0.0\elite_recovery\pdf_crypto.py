"""Fast verification of PDF Standard Security Handler passwords.

The implementation follows ISO 32000-1 algorithms 2, 3, 4, 5 and 6 and the
ISO 32000-2 algorithm 2.B (revision 6).  It deliberately verifies only the
password, so it never has to decrypt the document body; this makes dictionary
tests dramatically faster than opening the PDF for every candidate.
"""

from __future__ import annotations

import hashlib
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from Crypto.Cipher import AES, ARC4
from pypdf import PdfReader
from pypdf.generic import IndirectObject

PADDING = bytes(
    [
        0x28, 0xBF, 0x4E, 0x5E, 0x4E, 0x75, 0x8A, 0x41,
        0x64, 0x00, 0x4E, 0x56, 0xFF, 0xFA, 0x01, 0x08,
        0x2E, 0x2E, 0x00, 0xB6, 0xD0, 0x68, 0x3E, 0x80,
        0x2F, 0x0C, 0xA9, 0xFE, 0x64, 0x53, 0x69, 0x7A,
    ]
)


class PDFCryptoError(Exception):
    """Base error for PDF encryption inspection."""


class PDFNotEncrypted(PDFCryptoError):
    """The PDF has no /Encrypt dictionary."""


class PDFUnsupported(PDFCryptoError):
    """The PDF uses an encryption handler ELITE Password Recovery cannot verify."""


def _raw(value: Any) -> bytes:
    """Return the original bytes of a pypdf string object."""
    if isinstance(value, bytes):
        return value
    original = getattr(value, "original_bytes", None)
    if isinstance(original, (bytes, bytearray)):
        return bytes(original)
    if isinstance(value, str):
        return value.encode("latin-1", "replace")
    try:
        return bytes(value)
    except Exception as exc:  # pragma: no cover - defensive
        raise PDFCryptoError(f"Cannot read PDF byte string: {value!r}") from exc


def _password_bytes(password: str, revision: int) -> bytes:
    if revision >= 5:
        # Revision 5/6 passwords are UTF-8 and truncated to 127 bytes.
        return password.encode("utf-8", "ignore")[:127]
    try:
        return password.encode("latin-1")
    except UnicodeEncodeError:
        # PDFDocEncoding is close to Latin-1.  For characters outside it, a
        # UTF-8 fallback gives useful results with files created by modern
        # software that wrote UTF-8 regardless of the specification.
        return password.encode("utf-8")


def _pad(password: bytes) -> bytes:
    return (password + PADDING)[:32]


@dataclass
class PDFEncryption:
    revision: int
    version: int
    key_bits: int
    owner: bytes
    user: bytes
    permissions: int
    file_id: bytes
    encrypt_metadata: bool = True
    owner_encrypted_key: bytes = b""
    user_encrypted_key: bytes = b""
    perms: bytes = b""
    try_owner: bool = False
    _kind: str = field(default="", init=False)

    @classmethod
    def from_file(cls, path: str | Path, try_owner: bool = False) -> "PDFEncryption":
        try:
            reader = PdfReader(str(path), strict=False)
        except Exception as exc:
            raise PDFCryptoError(f"Could not parse PDF: {exc}") from exc

        if not reader.is_encrypted:
            raise PDFNotEncrypted("This PDF does not require a password.")

        encrypt = reader.trailer.get("/Encrypt")
        if isinstance(encrypt, IndirectObject):
            encrypt = encrypt.get_object()
        if encrypt is None:
            raise PDFNotEncrypted("This PDF does not require a password.")

        filter_name = str(encrypt.get("/Filter", ""))
        if filter_name != "/Standard":
            raise PDFUnsupported(
                "This PDF uses public-key (certificate) security, which is not supported."
            )

        revision = int(encrypt.get("/R", 0))
        version = int(encrypt.get("/V", 0))
        if revision not in (2, 3, 4, 5, 6):
            raise PDFUnsupported(f"Unsupported PDF encryption revision R={revision}.")

        key_bits = int(encrypt.get("/Length", 40 if revision == 2 else 128))
        if revision == 2:
            key_bits = 40
        if revision in (3, 4):
            key_bits = max(40, min(128, key_bits))
            # Some writers omit /Length for 128-bit encryption.
            if key_bits == 40 and version >= 2:
                key_bits = 128

        owner = _raw(encrypt.get("/O", b""))
        user = _raw(encrypt.get("/U", b""))
        if revision <= 4 and (len(owner) < 32 or len(user) < 32):
            raise PDFCryptoError("Malformed /O or /U entry in the encryption dictionary.")
        if revision >= 5 and (len(owner) < 48 or len(user) < 48):
            raise PDFCryptoError("Malformed /O or /U entry in the encryption dictionary.")

        ids = reader.trailer.get("/ID")
        file_id = b""
        if ids:
            try:
                file_id = _raw(ids[0])
            except Exception:
                file_id = b""

        metadata = encrypt.get("/EncryptMetadata", True)
        encrypt_metadata = bool(metadata)

        obj = cls(
            revision=revision,
            version=version,
            key_bits=key_bits,
            owner=owner,
            user=user,
            permissions=int(encrypt.get("/P", 0)),
            file_id=file_id,
            encrypt_metadata=encrypt_metadata,
            owner_encrypted_key=_raw(encrypt.get("/OE", b"")),
            user_encrypted_key=_raw(encrypt.get("/UE", b"")),
            perms=_raw(encrypt.get("/Perms", b"")),
            try_owner=try_owner,
        )
        obj._kind = obj._describe()
        return obj

    @property
    def key_length(self) -> int:
        return 5 if self.revision == 2 else max(5, self.key_bits // 8)

    @property
    def kind(self) -> str:
        return self._kind

    def _describe(self) -> str:
        if self.revision == 2:
            return "PDF · RC4-40 (R2)"
        if self.revision == 3:
            return f"PDF · RC4-{self.key_bits} (R3)"
        if self.revision == 4:
            # Most R4 files use AESV2; RC4-128 is also possible.
            return f"PDF · AES-128 / RC4 (R4)"
        if self.revision == 5:
            return "PDF · AES-256 (R5)"
        return "PDF · AES-256 (R6)"

    def verify(self, password: str) -> bool:
        pwd = _password_bytes(password, self.revision)
        if self.revision <= 4:
            if self._verify_user_legacy(_pad(pwd)):
                return True
            return self.try_owner and self._verify_owner_legacy(pwd)
        if self._verify_user_v5(pwd):
            return True
        return self.try_owner and self._verify_owner_v5(pwd)

    # ------------------------------------------------------------------
    # Revision 2-4
    # ------------------------------------------------------------------
    def _user_key(self, padded: bytes) -> bytes:
        digest = hashlib.md5()
        digest.update(padded)
        digest.update(self.owner[:32])
        digest.update(struct.pack("<I", self.permissions & 0xFFFFFFFF))
        digest.update(self.file_id)
        if self.revision >= 4 and not self.encrypt_metadata:
            digest.update(b"\xff\xff\xff\xff")
        key = digest.digest()
        if self.revision >= 3:
            for _ in range(50):
                key = hashlib.md5(key[: self.key_length]).digest()
        return key[: self.key_length]

    def _verify_user_legacy(self, padded: bytes) -> bool:
        key = self._user_key(padded)
        if self.revision == 2:
            return ARC4.new(key).encrypt(PADDING) == self.user[:32]
        digest = hashlib.md5(PADDING + self.file_id).digest()
        value = ARC4.new(key).encrypt(digest)
        for i in range(1, 20):
            value = ARC4.new(bytes(b ^ i for b in key)).encrypt(value)
        return value[:16] == self.user[:16]

    def _verify_owner_legacy(self, password: bytes) -> bool:
        owner_key = hashlib.md5(_pad(password)).digest()
        if self.revision >= 3:
            for _ in range(50):
                owner_key = hashlib.md5(owner_key).digest()
        owner_key = owner_key[: self.key_length]

        if self.revision == 2:
            user_padded = ARC4.new(owner_key).encrypt(self.owner[:32])
        else:
            value = self.owner[:32]
            # Decrypt is the inverse of the 20-round encryption: i = 19..0.
            for i in range(19, -1, -1):
                value = ARC4.new(bytes(b ^ i for b in owner_key)).encrypt(value)
            user_padded = value
        return self._verify_user_legacy(user_padded)

    # ------------------------------------------------------------------
    # Revision 5-6
    # ------------------------------------------------------------------
    @staticmethod
    def _hash_v5(password: bytes, salt: bytes, udata: bytes, revision: int) -> bytes:
        password = password[:127]
        key = hashlib.sha256(password + salt + udata).digest()
        if revision < 6:
            return key

        count = 0
        while True:
            count += 1
            block = (password + key + udata) * 64
            encrypted = AES.new(key[:16], AES.MODE_CBC, key[16:32]).encrypt(block)
            selector = sum(encrypted[:16]) % 3
            if selector == 0:
                key = hashlib.sha256(encrypted).digest()
            elif selector == 1:
                key = hashlib.sha384(encrypted).digest()
            else:
                key = hashlib.sha512(encrypted).digest()
            if count >= 64 and encrypted[-1] <= count - 32:
                break
        return key[:32]

    def _verify_user_v5(self, password: bytes) -> bool:
        salt = self.user[32:40]
        checksum = self._hash_v5(password, salt, b"", self.revision)
        return checksum == self.user[:32]

    def _verify_owner_v5(self, password: bytes) -> bool:
        salt = self.owner[32:40]
        checksum = self._hash_v5(password, salt, self.user[:48], self.revision)
        return checksum == self.owner[:32]


class PDFVerifier:
    """Verifier facade with the same interface as the other formats."""

    kind = "pdf"

    def __init__(self, path: str | Path, try_owner: bool = False):
        self.path = Path(path)
        self.encryption = PDFEncryption.from_file(self.path, try_owner=try_owner)
        self.kind = self.encryption.kind
        self.owner_supported = True

    def verify(self, password: str) -> bool:
        return self.encryption.verify(password)

    def close(self) -> None:
        pass
