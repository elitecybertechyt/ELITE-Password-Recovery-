"""Generate ELITE Password Recovery icon and UI logo assets."""
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets"
ASSETS.mkdir(exist_ok=True)

S = 1024
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
d.rounded_rectangle(
    (24, 24, S - 24, S - 24),
    radius=210,
    fill=(15, 20, 25, 255),
    outline=(45, 212, 191, 255),
    width=18,
)
d.arc((300, 220, 724, 660), start=180, end=360, fill=(45, 212, 191, 255), width=72)
d.line((300, 430, 300, 560), fill=(45, 212, 191, 255), width=72)
d.line((724, 430, 724, 560), fill=(45, 212, 191, 255), width=72)
d.rounded_rectangle((250, 480, 774, 850), radius=90, fill=(45, 212, 191, 255))
d.ellipse((455, 575, 569, 689), fill=(15, 20, 25, 255))
d.polygon([(491, 665), (533, 665), (560, 790), (464, 790)], fill=(15, 20, 25, 255))

img.save(ASSETS / "elite.png")
img.resize((64, 64), Image.LANCZOS).save(ASSETS / "logo-64.png")
img.resize((96, 96), Image.LANCZOS).save(ASSETS / "logo-96.png")
img.save(
    ASSETS / "elite.ico",
    sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
)
print("assets written to", ASSETS)
