"""Command-line interface for ELITE Password Recovery."""

from __future__ import annotations

import argparse
import json
import string
import sys
import time
from pathlib import Path

from . import __version__
from .candidates import BrutePlan, DictionaryPlan, MaskPlan, parse_custom_sets
from .engine import CrackController, recommended_batch_size
from .resources import resource_path
from .verifiers import inspect_file


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="elite-recovery",
        description="Recover the password of a PDF, Office, ZIP or 7z document you own.",
    )
    parser.add_argument("file", help="protected document")
    parser.add_argument("--info", action="store_true", help="inspect the file and exit")
    parser.add_argument("-w", "--wordlist", action="append", default=[], help="wordlist (repeatable)")
    parser.add_argument("--builtin", action="store_true", help="also use the built-in top-10,000 list")
    parser.add_argument(
        "--rules", choices=["none", "light", "medium"], default="light", help="dictionary mutations"
    )
    parser.add_argument("--filename", action="store_true", help="try words from the filename")
    parser.add_argument("--mask", help="mask pattern, e.g. ?u?l?l?l?d?d")
    parser.add_argument("--custom-sets", default="", help="custom mask sets: 1=abc;2=XYZ")
    parser.add_argument("--brute", action="store_true", help="brute-force mode")
    parser.add_argument(
        "--charset",
        default="lower,digits",
        help="brute-force sets: lower,upper,digits,symbols,space or literal characters",
    )
    parser.add_argument("--min", type=int, default=1, dest="min_length", help="minimum length")
    parser.add_argument("--max", type=int, default=4, dest="max_length", help="maximum length")
    parser.add_argument("--workers", type=int, default=0, help="worker processes (default: auto)")
    parser.add_argument("--owner", action="store_true", help="also test PDF owner passwords (slower)")
    parser.add_argument("--json", action="store_true", help="print the result as JSON")
    parser.add_argument("--quiet", action="store_true", help="disable progress output")
    parser.add_argument("--yes", action="store_true", help="confirm authorized use non-interactively")
    parser.add_argument("--version", action="version", version=f"ELITE Password Recovery {__version__}")
    return parser


def _charset(spec: str) -> str:
    groups = {
        "lower": string.ascii_lowercase,
        "upper": string.ascii_uppercase,
        "digits": string.digits,
        "symbols": string.punctuation,
        "space": " ",
    }
    parts = []
    for item in spec.split(","):
        item = item.strip()
        if item in groups:
            parts.append(groups[item])
        elif item:
            parts.append(item)
    return "".join(dict.fromkeys("".join(parts)))


def _build_plan(args):
    if args.mask:
        return MaskPlan(
            pattern=args.mask,
            custom_sets=parse_custom_sets(args.custom_sets),
        )
    if args.brute:
        return BrutePlan(
            chars=_charset(args.charset),
            min_length=args.min_length,
            max_length=args.max_length,
        )
    lists = list(args.wordlist)
    if args.builtin or not lists:
        lists.append(str(resource_path("wordlists/common-passwords.txt")))
    for path in lists:
        if not Path(path).is_file():
            raise SystemExit(f"Wordlist not found: {path}")
    return DictionaryPlan(
        wordlists=lists,
        rules=args.rules,
        include_filename=args.filename,
        filename=Path(args.file).name,
    )


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if not args.yes and not args.quiet:
        print(
            "ELITE Password Recovery — use only on documents you own or are authorized to access.",
            file=sys.stderr,
        )

    report = inspect_file(args.file)
    if args.info:
        print(json.dumps(report.__dict__, default=str, indent=2))
        return 0 if report.supported else 2
    if not report.supported:
        print(f"Unsupported: {report.note}", file=sys.stderr)
        return 2
    if not report.encrypted:
        print("This document is not password protected.", file=sys.stderr)
        return 0

    try:
        plan = _build_plan(args)
        estimate = plan.estimate()
    except SystemExit:
        raise
    except Exception as exc:
        print(f"Cannot build candidate list: {exc}", file=sys.stderr)
        return 2

    workers = args.workers or 0
    if workers <= 0:
        import os

        workers = max(1, min(8, os.cpu_count() or 1))

    if not args.quiet:
        print(f"Target: {report.path.name}", file=sys.stderr)
        print(f"Format: {report.label}", file=sys.stderr)
        print(f"Method: {plan.describe()}", file=sys.stderr)
        print(f"Search space: {estimate:,} candidates" if estimate else "Search space: unknown", file=sys.stderr)

    result_holder = {}

    def on_progress(snapshot) -> None:
        if args.quiet:
            return
        eta = f" ETA {int(snapshot.eta)}s" if snapshot.eta is not None else ""
        print(
            f"\r{snapshot.tried:,} tried · {snapshot.speed:,.0f}/s{eta}   ",
            end="",
            file=sys.stderr,
            flush=True,
        )

    def on_done(result) -> None:
        result_holder["result"] = result
        if not args.quiet:
            print("\r" + " " * 70 + "\r", end="", file=sys.stderr)
            print(result.reason + (f": {result.password}" if result.found else ""), file=sys.stderr)

    controller = CrackController(
        path=args.file,
        plan=plan,
        workers=workers,
        try_owner=args.owner,
        batch_size=recommended_batch_size(report.label),
        estimate=estimate,
        on_progress=on_progress,
        on_done=on_done,
    )
    started = time.monotonic()
    controller.start()
    controller.join()
    result = result_holder.get("result")
    if result is None:
        print("Recovery failed to start.", file=sys.stderr)
        return 2

    if args.json:
        print(
            json.dumps(
                {
                    "found": result.found,
                    "password": result.password,
                    "tried": result.tried,
                    "elapsed": result.elapsed,
                    "reason": result.reason,
                    "error": result.error,
                    "format": report.label,
                    "file": str(report.path),
                },
                ensure_ascii=False,
            )
        )
    elif result.found:
        print(result.password)
    elif result.reason == "error":
        print(f"Error: {result.error}", file=sys.stderr)
    return 0 if result.found else (2 if result.reason == "error" else 1)


if __name__ == "__main__":
    raise SystemExit(main())
