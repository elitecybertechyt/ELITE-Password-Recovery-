"""Locate bundled resources both from source and from a PyInstaller build."""

from __future__ import annotations

import sys
from pathlib import Path


def app_root() -> Path:
    bundled = getattr(sys, "_MEIPASS", None)
    if bundled:
        return Path(bundled)
    return Path(__file__).resolve().parent.parent


def resource_path(relative: str | Path) -> Path:
    return app_root() / relative


def settings_path() -> Path:
    import os

    base = os.environ.get("APPDATA")
    if base:
        folder = Path(base) / "ELITE Password Recovery"
    else:
        folder = Path.home() / ".elite-password-recovery"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "settings.json"
