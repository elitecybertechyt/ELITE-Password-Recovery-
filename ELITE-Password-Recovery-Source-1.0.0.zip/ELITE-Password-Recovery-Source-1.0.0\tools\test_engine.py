from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from elite_recovery.candidates import DictionaryPlan, MaskPlan
from elite_recovery.engine import CrackController, recommended_batch_size
from elite_recovery.verifiers import inspect_file


def run(path: str, plan, workers: int = 4) -> None:
    report = inspect_file(path)
    print(f"\n=== {path}: {report.label} ===")
    estimate = plan.estimate()
    print("estimate:", estimate)
    batch = recommended_batch_size(report.label)
    done = {}
    start = time.perf_counter()

    def on_progress(s):
        if int(s.elapsed * 2) != int((s.elapsed - 0.15) * 2):
            print(f"  {s.tried:8d}  {s.speed:9.0f}/s  {s.elapsed:6.1f}s", end="\r")

    def on_done(r):
        done["r"] = r
        print(f"\n  -> found={r.found} pw={r.password!r} tried={r.tried} "
              f"reason={r.reason} elapsed={r.elapsed:.2f}s")

    controller = CrackController(
        path, plan, workers=workers, batch_size=batch, estimate=estimate,
        on_progress=on_progress, on_done=on_done, on_log=print,
    )
    controller.start()
    controller.join(timeout=120)
    print("controller alive:", controller.running, "wall:", time.perf_counter() - start)


if __name__ == "__main__":
    run("samples/sample_rc4_40.pdf",
        DictionaryPlan(wordlists=["samples/test_words.txt"], rules="none", include_filename=False))
    run("samples/sample_aes256_r6.pdf",
        DictionaryPlan(wordlists=["samples/test_words.txt"], rules="none", include_filename=False))
    run("samples/office/example_password.docx",
        DictionaryPlan(wordlists=["samples/office_words.txt"], rules="none", include_filename=False), workers=2)
    run("samples/sample_aes.zip",
        MaskPlan(pattern="secret?d?d?d"), workers=4)
