"""Multiprocess cracking engine.

The parent process streams candidate batches to worker processes.  Each worker
opens the document once, then checks candidates until it finds the password,
runs out of work, or is asked to stop.
"""

from __future__ import annotations

import multiprocessing as mp
import os
import queue
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from .candidates import CandidatePlan
from .verifiers import build_verifier


def recommended_batch_size(label: str) -> int:
    """Choose an IPC batch size based on how expensive one check is."""
    text = label.lower()
    if "agile" in text or "7z" in text:
        return 1
    if "standard" in text:
        return 4
    if "r6" in text:
        return 64
    if "aes" in text or "zip" in text:
        return 32
    if "office" in text:
        return 64
    return 256


def default_worker_count() -> int:
    cpu = os.cpu_count() or 1
    return max(1, min(8, cpu))


@dataclass
class CrackResult:
    found: bool
    password: Optional[str]
    tried: int
    elapsed: float
    reason: str
    error: Optional[str] = None


@dataclass
class ProgressSnapshot:
    tried: int
    elapsed: float
    speed: float
    eta: Optional[float]
    percent: Optional[float]
    estimate: Optional[int]


# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------
def _worker(
    path: str,
    try_owner: bool,
    task_queue,
    result_queue,
    stop_event,
) -> None:
    verifier = None
    tried_note = False
    try:
        verifier = build_verifier(path, try_owner=try_owner)
        result_queue.put(("ready", os.getpid()))
        while not stop_event.is_set():
            try:
                item = task_queue.get(timeout=0.2)
            except queue.Empty:
                continue
            if item is None:
                break
            passwords = item
            tried = 0
            for password in passwords:
                if stop_event.is_set():
                    break
                tried += 1
                try:
                    if verifier.verify(password):
                        result_queue.put(("hit", password, tried))
                        stop_event.set()
                        return
                except Exception as exc:
                    # Candidate-specific failures (odd encodings, a damaged
                    # entry, ...) should not abort the whole search.  Report
                    # the first one and keep going.
                    if not tried_note:
                        result_queue.put(
                            ("note", f"Skipped a candidate after {type(exc).__name__}: {exc}")
                        )
                        tried_note = True
            if tried:
                result_queue.put(("progress", tried))
    except Exception as exc:
        result_queue.put(("worker_error", f"{type(exc).__name__}: {exc}"))
        stop_event.set()
    finally:
        if verifier is not None:
            try:
                verifier.close()
            except Exception:
                pass
        result_queue.put(("worker_done", os.getpid()))


# ---------------------------------------------------------------------------
# Controller
# ---------------------------------------------------------------------------
class CrackController:
    def __init__(
        self,
        path: str | Path,
        plan: CandidatePlan,
        workers: int = 4,
        try_owner: bool = False,
        batch_size: int = 128,
        estimate: Optional[int] = None,
        on_progress: Optional[Callable[[ProgressSnapshot], None]] = None,
        on_done: Optional[Callable[[CrackResult], None]] = None,
        on_log: Optional[Callable[[str], None]] = None,
    ):
        self.path = str(path)
        self.plan = plan
        self.workers = max(1, int(workers))
        self.try_owner = try_owner
        self.batch_size = max(1, int(batch_size))
        self.estimate = estimate
        self.on_progress = on_progress
        self.on_done = on_done
        self.on_log = on_log

        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._processes: list[mp.Process] = []
        self._started = 0.0
        self._tried = 0
        self._hit: Optional[str] = None
        self._error: Optional[str] = None
        self._lock = threading.Lock()

    # -- public API -----------------------------------------------------
    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def start(self) -> None:
        if self.running:
            return
        self._thread = threading.Thread(target=self._run, name="EliteRecoveryEngine", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def join(self, timeout: Optional[float] = None) -> None:
        if self._thread:
            self._thread.join(timeout)

    # -- thread body ----------------------------------------------------
    def _emit_progress(self) -> None:
        elapsed = max(1e-9, time.monotonic() - self._started)
        speed = self._tried / elapsed
        eta = None
        percent = None
        if self.estimate and self.estimate > 0:
            eta = max(0.0, (self.estimate - self._tried) / speed) if speed > 0 else None
            percent = min(1.0, self._tried / self.estimate)
        snapshot = ProgressSnapshot(
            tried=self._tried,
            elapsed=elapsed,
            speed=speed,
            eta=eta,
            percent=percent,
            estimate=self.estimate,
        )
        if self.on_progress:
            try:
                self.on_progress(snapshot)
            except Exception:
                pass

    def _log(self, message: str) -> None:
        if self.on_log:
            try:
                self.on_log(message)
            except Exception:
                pass

    def _run(self) -> None:
        self._started = time.monotonic()
        ctx = mp.get_context("spawn")
        task_queue = ctx.Queue(maxsize=max(8, self.workers * 4))
        result_queue = ctx.Queue()
        stop_event = ctx.Event()

        processes: list[mp.Process] = []
        producer: Optional[threading.Thread] = None
        producer_done = threading.Event()
        worker_done = 0

        def producer_body() -> None:
            nonlocal producer
            try:
                batch: list[str] = []
                for candidate in self.plan.candidates():
                    if self._stop.is_set() or stop_event.is_set():
                        break
                    batch.append(candidate)
                    if len(batch) >= self.batch_size:
                        while not (self._stop.is_set() or stop_event.is_set()):
                            try:
                                task_queue.put(batch, timeout=0.2)
                                break
                            except queue.Full:
                                continue
                        batch = []
                        if self._stop.is_set() or stop_event.is_set():
                            break
                if batch and not (self._stop.is_set() or stop_event.is_set()):
                    while not (self._stop.is_set() or stop_event.is_set()):
                        try:
                            task_queue.put(batch, timeout=0.2)
                            break
                        except queue.Full:
                            continue
                for _ in range(self.workers):
                    while not stop_event.is_set():
                        try:
                            task_queue.put(None, timeout=0.2)
                            break
                        except queue.Full:
                            continue
            except Exception as exc:
                result_queue.put(("worker_error", f"Candidate generation failed: {exc}"))
                stop_event.set()
            finally:
                producer_done.set()

        try:
            for _ in range(self.workers):
                process = ctx.Process(
                    target=_worker,
                    args=(self.path, self.try_owner, task_queue, result_queue, stop_event),
                    daemon=True,
                )
                process.start()
                processes.append(process)
            self._processes = processes

            producer = threading.Thread(target=producer_body, name="EliteRecoveryProducer", daemon=True)
            producer.start()

            last_emit = 0.0
            while True:
                if self._stop.is_set() and not stop_event.is_set():
                    stop_event.set()

                try:
                    message = result_queue.get(timeout=0.15)
                except queue.Empty:
                    message = None

                if message is not None:
                    kind = message[0]
                    if kind == "progress":
                        self._tried += int(message[1])
                    elif kind == "hit":
                        self._hit = str(message[1])
                        self._tried += int(message[2])
                        stop_event.set()
                    elif kind == "worker_error":
                        self._error = str(message[1])
                        stop_event.set()
                    elif kind == "note":
                        self._log(str(message[1]))
                    elif kind == "worker_done":
                        worker_done += 1

                now = time.monotonic()
                if now - last_emit >= 0.15:
                    self._emit_progress()
                    last_emit = now

                if self._hit or self._error:
                    break
                if self._stop.is_set():
                    break
                if producer_done.is_set() and worker_done >= len(processes) and message is None:
                    break

            elapsed = time.monotonic() - self._started
            self._emit_progress()

            if self._hit:
                reason = "found"
                result = CrackResult(True, self._hit, self._tried, elapsed, reason)
            elif self._error:
                result = CrackResult(False, None, self._tried, elapsed, "error", self._error)
            elif self._stop.is_set():
                result = CrackResult(False, None, self._tried, elapsed, "stopped")
            else:
                result = CrackResult(False, None, self._tried, elapsed, "exhausted")

            if self.on_done:
                try:
                    self.on_done(result)
                except Exception:
                    pass

        except Exception as exc:
            elapsed = time.monotonic() - self._started
            result = CrackResult(False, None, self._tried, elapsed, "error", str(exc))
            if self.on_done:
                try:
                    self.on_done(result)
                except Exception:
                    pass
        finally:
            stop_event.set()
            if producer is not None:
                producer.join(timeout=1.0)
            for process in processes:
                if process.is_alive():
                    process.terminate()
            for process in processes:
                try:
                    process.join(timeout=2.0)
                except Exception:
                    pass
            for q in (task_queue, result_queue):
                try:
                    q.cancel_join_thread()
                    q.close()
                except Exception:
                    pass
            self._processes = []
