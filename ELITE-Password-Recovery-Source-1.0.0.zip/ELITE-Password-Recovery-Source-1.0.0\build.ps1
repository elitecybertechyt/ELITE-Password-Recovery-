# Build ELITE Password Recovery and its Windows installer.
$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

$Python = Join-Path $Root ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) {
    throw "Virtual environment not found. Run: python -m venv .venv; .\.venv\Scripts\python.exe -m pip install -r requirements.txt"
}

Write-Host "==> Building application folder" -ForegroundColor Cyan
& $Python -m PyInstaller `
    --noconfirm `
    --clean `
    --onedir `
    --windowed `
    --name "ELITE-Password-Recovery" `
    --icon "$Root\assets\elite.ico" `
    --version-file "$Root\build\version_info.txt" `
    --add-data "$Root\assets;assets" `
    --add-data "$Root\wordlists;wordlists" `
    --hidden-import "msoffcrypto.format.ooxml" `
    --hidden-import "msoffcrypto.format.doc97" `
    --hidden-import "msoffcrypto.format.xls97" `
    --hidden-import "msoffcrypto.format.ppt97" `
    --hidden-import "pyzipper" `
    --hidden-import "py7zr" `
    --hidden-import "Crypto.Cipher.AES" `
    --hidden-import "Crypto.Cipher.ARC4" `
    --collect-submodules "py7zr" `
    --distpath "dist" `
    --workpath "build\pyinstaller" `
    --specpath "build" `
    "app.py"
if ($LASTEXITCODE -ne 0) { throw "PyInstaller failed with exit code $LASTEXITCODE" }

$Exe = Join-Path $Root "dist\ELITE-Password-Recovery\ELITE-Password-Recovery.exe"
if (-not (Test-Path $Exe)) { throw "Expected executable was not created: $Exe" }
$FolderSize = (Get-ChildItem (Split-Path $Exe) -Recurse -File | Measure-Object Length -Sum).Sum
Write-Host ("    {0} ({1:N1} MB folder)" -f $Exe, ($FolderSize / 1MB)) -ForegroundColor Green

$Iscc = Join-Path $env:LOCALAPPDATA "Programs\Inno Setup 6\ISCC.exe"
if (-not (Test-Path $Iscc)) {
    $Iscc = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
}
if (-not (Test-Path $Iscc)) {
    throw "Inno Setup 6 (ISCC.exe) was not found. Install it from https://jrsoftware.org/isdl.php"
}

Write-Host "==> Compiling installer" -ForegroundColor Cyan
$Downloads = Join-Path $env:USERPROFILE "Downloads"
New-Item -ItemType Directory -Force -Path $Downloads | Out-Null
& $Iscc "/DMyOutputDir=$Downloads" "installer\ELITE-Password-Recovery.iss"
if ($LASTEXITCODE -ne 0) { throw "Inno Setup failed with exit code $LASTEXITCODE" }

$Setup = Join-Path $env:USERPROFILE "Downloads\ELITE-Password-Recovery-Setup-1.0.0.exe"
if (-not (Test-Path $Setup)) { throw "Expected installer was not created: $Setup" }
$Hash = (Get-FileHash $Setup -Algorithm SHA256).Hash
Write-Host ""
Write-Host "Installer ready:" -ForegroundColor Green
Write-Host "  $Setup"
Write-Host ("  {0:N1} MB  ·  SHA256 {1}" -f ((Get-Item $Setup).Length / 1MB), $Hash)
