"""ELITE Password Recovery — local password recovery for protected documents."""

__version__ = "1.0.0"
