# Third-party notices

ELITE Password Recovery bundles or depends on the following open-source
projects. Their licenses apply to their respective code.

| Component | Purpose | License |
|---|---|---|
| [pypdf](https://github.com/py-pdf/pypdf) | PDF parsing and encryption metadata | BSD-3-Clause |
| [msoffcrypto-tool](https://github.com/nolze/msoffcrypto-tool) | Office encryption verification | MIT |
| [olefile](https://github.com/decalage2/olefile) | Compound File Binary parsing | BSD-2-Clause |
| [pyzipper](https://github.com/danifus/pyzipper) | ZIP AES and ZipCrypto | MIT |
| [py7zr](https://github.com/miurahr/py7zr) | 7z archive support | LGPL-2.1-or-later |
| [PyCryptodome](https://www.pycryptodome.org/) | AES and RC4 primitives | BSD-2-Clause |
| [cryptography](https://github.com/pyca/cryptography) | Cryptographic primitives (via msoffcrypto) | Apache-2.0 OR BSD-3-Clause |
| [Pillow](https://python-pillow.org/) | Build-time icon/artwork generation | MIT-CMU |
| [Python](https://www.python.org/) | Runtime | PSF License |
| [Tcl/Tk](https://www.tcl.tk/) | GUI toolkit | BSD-style |
| [PyInstaller](https://pyinstaller.org/) | Frozen Windows executable | GPL-2.0 with bootloader exception |
| [Inno Setup](https://jrsoftware.org/isinfo.php) | Windows installer | Freeware |
| [SecLists](https://github.com/danielmiessler/SecLists) | Built-in Pwdb Top 10,000 wordlist | MIT |

## Notes

- **py7zr** is distributed under the GNU Lesser General Public License
  (LGPL-2.1-or-later). Its source is available at the link above. The
  application loads it as a Python module for 7z support; you may replace it
  with a compatible version.
- **PyInstaller** is used as a build tool. Its bootloader exception permits
  distribution of bundled applications.
- **Inno Setup** is used only to produce the installer.
- The built-in `wordlists/common-passwords.txt` is derived from the Pwdb Top
  10,000 list in SecLists, used under the MIT license.

Full license texts are available at the project links above. If you redistribute
this application, keep this notice with it.
