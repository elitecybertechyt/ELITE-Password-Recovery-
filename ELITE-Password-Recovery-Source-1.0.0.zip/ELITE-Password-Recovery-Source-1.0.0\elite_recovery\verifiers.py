"""Password verifiers for the document formats ELITE Password Recovery supports.

Every verifier exposes the same tiny interface::

    verifier = build_verifier(path)
    if verifier.verify("candidate"):
        ...

Verifiers are intentionally cheap: they only check the password, never decrypt
the complete document.  They are created once per worker process and reused
for thousands of candidates.
"""

from __future__ import annotations

import os
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import msoffcrypto
import olefile
import py7zr
import pyzipper
from msoffcrypto.exceptions import InvalidKeyError

from .pdf_crypto import (
    PDFCryptoError,
    PDFNotEncrypted,
    PDFUnsupported,
    PDFVerifier,
)


class VerifierError(Exception):
    """A file could not be prepared for password testing."""


class NotEncryptedError(VerifierError):
    """The file does not require a password."""


class UnsupportedFormatError(VerifierError):
    """The file is encrypted with an unsupported scheme."""


@dataclass
class FileReport:
    path: Path
    kind: str
    label: str
    encrypted: bool
    supported: bool
    note: str = ""
    size: int = 0

    @property
    def name(self) -> str:
        return self.path.name

    @property
    def status_text(self) -> str:
        if not self.supported:
            return self.note or "Unsupported format"
        if not self.encrypted:
            return "No password required"
        return self.label


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------
class OfficePasswordVerifier:
    kind = "office"

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._handle = self.path.open("rb")
        try:
            self._office = msoffcrypto.OfficeFile(self._handle)
        except Exception as exc:
            self._handle.close()
            raise UnsupportedFormatError(f"Unrecognized Office document: {exc}") from exc

        if not self._office.is_encrypted():
            self._handle.close()
            raise NotEncryptedError("This document is not password protected.")

        self._format = getattr(self._office, "format", "")
        self._type = getattr(self._office, "type", "")
        self._ooxml = self._format == "ooxml"
        self.kind = self._describe()
        self.owner_supported = False

        # Some legacy Office variants are not supported by msoffcrypto.  Probe
        # with a sentinel so the GUI reports that immediately, not after an
        # hour of futile candidates.
        try:
            if self._ooxml:
                self._office.load_key(password="\x00ELITE Password Recovery probe\x00", verify_password=True)
            else:
                self._office.load_key(password="\x00ELITE Password Recovery probe\x00")
        except InvalidKeyError:
            pass
        except Exception as exc:
            self._handle.close()
            raise UnsupportedFormatError(f"Unsupported Office encryption: {exc}") from exc

    def _describe(self) -> str:
        if self._ooxml:
            if self._type == "agile":
                info = getattr(self._office, "info", {}) or {}
                cipher = str(info.get("cipherAlgorithm", "AES")).upper()
                if not cipher.startswith("AES"):
                    cipher = f"{cipher}-AES"
                bits = info.get("passwordKeyBits") or info.get("keyBits") or 256
                return f"Office · Agile {cipher}-{bits}"
            if self._type == "standard":
                info = getattr(self._office, "info", {}) or {}
                header = info.get("header", {}) or {}
                bits = header.get("keySize", 128)
                algorithm = "AES" if header.get("algId") in (0x660E, 0x660F, 0x6610) else "RC4"
                return f"Office · Standard {algorithm}-{bits}"
            return "Office · encrypted OOXML"
        names = {
            "doc97": "Word 97-2003",
            "xls97": "Excel 97-2003",
            "ppt97": "PowerPoint 97-2003",
        }
        return f"Office · {names.get(self._format, 'legacy')} RC4"

    def verify(self, password: str) -> bool:
        if not password:
            # msoffcrypto treats an empty password as "no key supplied", so it
            # cannot verify this candidate.  An empty password on an encrypted
            # Office file is vanishingly rare.
            return False
        try:
            if self._ooxml:
                self._office.load_key(password=password, verify_password=True)
            else:
                self._office.load_key(password=password)
            return True
        except InvalidKeyError:
            return False
        except Exception:
            # A handful of malformed legacy files raise a codec error for
            # wrong passwords instead of InvalidKeyError.
            return False

    def close(self) -> None:
        try:
            self._handle.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# ZIP
# ---------------------------------------------------------------------------
class ZipPasswordVerifier:
    kind = "zip"

    def __init__(self, path: str | Path):
        self.path = Path(path)
        try:
            self._zip = pyzipper.AESZipFile(self.path, "r")
        except Exception as exc:
            raise UnsupportedFormatError(f"Could not open ZIP: {exc}") from exc

        encrypted = [i for i in self._zip.infolist() if i.flag_bits & 0x1 and not i.is_dir()]
        if not encrypted:
            self._zip.close()
            raise NotEncryptedError("This ZIP archive is not encrypted.")

        # Smallest member gives the cheapest reliable password check.
        self._target = min(encrypted, key=lambda i: (i.file_size, i.compress_size))
        # WinZip AES stores a 0x9901 extra field ("AE" vendor, strength 1-3).
        self._aes = self._target.extra[:2] == b"\x01\x99"
        self.kind = "ZIP · AES-256" if self._aes else "ZIP · ZipCrypto"
        self.owner_supported = False

    def verify(self, password: str) -> bool:
        if not password:
            return False
        self._zip.setpassword(password.encode("utf-8", "ignore"))
        try:
            with self._zip.open(self._target) as fh:
                while fh.read(1024 * 1024):
                    pass
            return True
        except (RuntimeError, zipfile.BadZipFile, ValueError, EOFError):
            return False
        except Exception:
            return False

    def close(self) -> None:
        try:
            self._zip.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# 7-Zip
# ---------------------------------------------------------------------------
class SevenZipPasswordVerifier:
    kind = "7z"

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._tempdir = tempfile.mkdtemp(prefix="elite-pwr-")
        self._target: Optional[str] = None
        no_files = False
        try:
            with py7zr.SevenZipFile(self.path, "r") as archive:
                files = [f for f in archive.files if not f.is_directory]
                if files:
                    self._target = min(files, key=lambda f: f.uncompressed).filename
                else:
                    no_files = True
                encrypted = archive.needs_password()
                header_encrypted = bool(getattr(archive, "header_encrypted", False))
        except Exception:
            # With header encryption py7zr cannot list anything until it has the
            # password.  Treat this as a supported header-encrypted archive; the
            # per-candidate open will reject wrong passwords.
            encrypted = True
            header_encrypted = True

        if no_files:
            shutil.rmtree(self._tempdir, ignore_errors=True)
            raise NotEncryptedError("This 7z archive contains no files.")
        if not encrypted:
            shutil.rmtree(self._tempdir, ignore_errors=True)
            raise NotEncryptedError("This 7z archive is not encrypted.")

        self._header_encrypted = header_encrypted
        self.kind = "7z · AES-256" + (" (header encrypted)" if header_encrypted else "")
        self.owner_supported = False

    def verify(self, password: str) -> bool:
        if not password:
            return False
        try:
            with py7zr.SevenZipFile(self.path, "r", password=password) as archive:
                target = self._target
                if target is None:
                    names = archive.getnames()
                    if not names:
                        return False
                    target = names[0]
                archive.extract(path=self._tempdir, targets=[target])
            return True
        except Exception:
            # Wrong passwords surface as LZMAError, CrcError, TypeError from the
            # encrypted header parser, or EOFError depending on the archive.
            return False

    def close(self) -> None:
        shutil.rmtree(self._tempdir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Factory / inspection
# ---------------------------------------------------------------------------
def _looks_like_ooxml(path: Path) -> bool:
    try:
        with zipfile.ZipFile(path) as zf:
            names = set(zf.namelist())
        return "[Content_Types].xml" in names and any(
            n.startswith(("word/", "xl/", "ppt/")) for n in names
        )
    except Exception:
        return False


def build_verifier(path: str | Path, try_owner: bool = False) -> object:
    """Create the right verifier, raising a descriptive VerifierError."""
    path = Path(path)
    if not path.is_file():
        raise VerifierError("The selected file does not exist.")
    try:
        with path.open("rb") as fh:
            header = fh.read(8)
    except OSError as exc:
        raise VerifierError(f"Cannot read file: {exc}") from exc

    try:
        if header.startswith(b"%PDF"):
            try:
                return PDFVerifier(path, try_owner=try_owner)
            except PDFNotEncrypted as exc:
                raise NotEncryptedError(str(exc)) from exc
            except PDFUnsupported as exc:
                raise UnsupportedFormatError(str(exc)) from exc
            except PDFCryptoError as exc:
                raise VerifierError(str(exc)) from exc

        if header.startswith(b"PK\x03\x04"):
            if _looks_like_ooxml(path):
                return OfficePasswordVerifier(path)
            return ZipPasswordVerifier(path)

        if header.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
            return OfficePasswordVerifier(path)

        if header.startswith(b"7z\xbc\xaf\x27\x1c"):
            return SevenZipPasswordVerifier(path)

        if header.startswith(b"Rar!\x1a\x07"):
            raise UnsupportedFormatError(
                "RAR archives need the external UnRAR engine and are not supported yet."
            )

        raise UnsupportedFormatError(
            "Unsupported file type. ELITE Password Recovery handles PDF, Office, ZIP and 7z files."
        )
    except NotEncryptedError:
        raise
    except UnsupportedFormatError:
        raise
    except VerifierError:
        raise
    except Exception as exc:
        raise VerifierError(f"Could not inspect file: {exc}") from exc


def inspect_file(path: str | Path, try_owner: bool = False) -> FileReport:
    """Return a GUI-friendly description of a document without cracking it."""
    path = Path(path)
    try:
        size = path.stat().st_size
    except OSError:
        size = 0
    try:
        verifier = build_verifier(path, try_owner=try_owner)
    except NotEncryptedError as exc:
        kind = _guess_kind(path)
        return FileReport(path, kind, "Not encrypted", False, True, str(exc), size)
    except UnsupportedFormatError as exc:
        return FileReport(path, _guess_kind(path), "Unsupported", True, False, str(exc), size)
    except VerifierError as exc:
        return FileReport(path, "unknown", "Error", False, False, str(exc), size)
    else:
        label = getattr(verifier, "kind", "Encrypted")
        verifier.close()
        return FileReport(path, label.split(" ")[0].lower(), label, True, True, "", size)


def _guess_kind(path: Path) -> str:
    try:
        with path.open("rb") as fh:
            header = fh.read(8)
        if header.startswith(b"%PDF"):
            return "pdf"
        if header.startswith(b"PK\x03\x04"):
            return "office" if _looks_like_ooxml(path) else "zip"
        if header.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
            return "office"
        if header.startswith(b"7z\xbc\xaf\x27\x1c"):
            return "7z"
        if header.startswith(b"Rar!\x1a\x07"):
            return "rar"
    except Exception:
        pass
    return "unknown"
