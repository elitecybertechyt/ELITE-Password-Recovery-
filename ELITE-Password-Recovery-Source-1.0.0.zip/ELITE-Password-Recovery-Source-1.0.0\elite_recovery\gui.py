"""ELITE Password Recovery desktop GUI (Tkinter, Windows-first)."""

from __future__ import annotations

import ctypes
import json
import os
import queue
import threading
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from . import __version__
from .candidates import (
    BrutePlan,
    CandidatePlan,
    DictionaryPlan,
    MaskPlan,
    parse_custom_sets,
)
from .engine import (
    CrackController,
    CrackResult,
    ProgressSnapshot,
    default_worker_count,
    recommended_batch_size,
)
from .resources import resource_path, settings_path
from .verifiers import FileReport, inspect_file

# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------
BG = "#0d1117"
SURFACE = "#161c24"
SURFACE_2 = "#1e2732"
SURFACE_3 = "#263241"
BORDER = "#2b3644"
TEXT = "#e6edf3"
MUTED = "#8b98a9"
FAINT = "#5c6b7c"
ACCENT = "#2dd4bf"
ACCENT_DARK = "#0f3d38"
ACCENT_HOVER = "#5eead4"
GREEN = "#34d399"
GREEN_DARK = "#0f2f26"
AMBER = "#fbbf24"
AMBER_DARK = "#332610"
RED = "#f87171"
RED_DARK = "#3a1717"

FONT = "Segoe UI"
MONO = "Consolas"

MODE_DICTIONARY = 0
MODE_BRUTE = 1
MODE_MASK = 2

RULE_LABELS = ["Exact words only", "Light mutations", "Medium mutations"]
RULE_KEYS = ["none", "light", "medium"]


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------
def human_count(value: int | float | None) -> str:
    if value is None:
        return "—"
    value = int(value)
    if value >= 1_000_000_000:
        return f"{value / 1_000_000_000:.2f}B"
    if value >= 1_000_000:
        return f"{value / 1_000_000:.2f}M"
    if value >= 1_000:
        return f"{value:,}"
    return str(value)


def human_speed(value: float) -> str:
    if value <= 0:
        return "—"
    if value >= 1_000_000:
        return f"{value / 1_000_000:.1f}M/s"
    if value >= 1_000:
        return f"{value:,.0f}/s"
    if value >= 10:
        return f"{value:.0f}/s"
    return f"{value:.1f}/s"


def human_duration(seconds: float | None) -> str:
    if seconds is None or seconds < 0:
        return "—"
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes}m {sec:02d}s"
    hours, minutes = divmod(minutes, 60)
    if hours < 24:
        return f"{hours}h {minutes:02d}m"
    days, hours = divmod(hours, 24)
    return f"{days}d {hours}h"


def human_size(value: int) -> str:
    if value < 1024:
        return f"{value} B"
    if value < 1024**2:
        return f"{value / 1024:.0f} KB"
    if value < 1024**3:
        return f"{value / 1024**2:.1f} MB"
    return f"{value / 1024**3:.2f} GB"


# ---------------------------------------------------------------------------
# Small widgets
# ---------------------------------------------------------------------------
class Card(tk.Frame):
    """A flat card with a one-pixel border and an inner padded body."""

    def __init__(self, parent: tk.Misc, **kwargs):
        super().__init__(parent, bg=BORDER, bd=0, highlightthickness=0, **kwargs)
        self.body = tk.Frame(self, bg=SURFACE, padx=15, pady=12)
        self.body.pack(fill="both", expand=True, padx=1, pady=1)
        self.body.grid_columnconfigure(0, weight=1)


def label(
    parent: tk.Misc,
    text: str,
    *,
    fg: str = TEXT,
    size: int = 10,
    bold: bool = False,
    bg: str = SURFACE,
    font: str = FONT,
    **kwargs,
) -> tk.Label:
    return tk.Label(
        parent,
        text=text,
        bg=bg,
        fg=fg,
        font=(font, size, "bold" if bold else "normal"),
        **kwargs,
    )


def entry(
    parent: tk.Misc,
    *,
    textvariable: tk.Variable | None = None,
    readonly: bool = False,
    bg: str = SURFACE_2,
    fg: str = TEXT,
    font: tuple = (FONT, 10),
    **kwargs,
) -> tk.Entry:
    widget = tk.Entry(
        parent,
        textvariable=textvariable,
        bg=bg,
        fg=fg,
        insertbackground=TEXT,
        disabledbackground=bg,
        disabledforeground=FAINT,
        readonlybackground=bg,
        relief="flat",
        bd=0,
        highlightthickness=1,
        highlightbackground=BORDER,
        highlightcolor=ACCENT,
        font=font,
        **kwargs,
    )
    if readonly:
        widget.configure(state="readonly")
    return widget


class ScrollColumn(tk.Frame):
    """A narrow column that scrolls when the window is too short."""

    def __init__(self, parent: tk.Misc, width: int = 360):
        super().__init__(parent, bg=BG, width=width)
        self.grid_propagate(False)
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0, bd=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.vbar = ttk.Scrollbar(
            self, orient="vertical", command=self.canvas.yview, style="Dark.Vertical.TScrollbar"
        )
        self.canvas.configure(yscrollcommand=self.vbar.set)
        self._bar_visible = False

        self.inner = tk.Frame(self.canvas, bg=BG)
        self.inner.grid_columnconfigure(0, weight=1)
        self._window = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", self._sync_region)
        self.canvas.bind("<Configure>", self._sync_width)
        self.canvas.bind("<Enter>", self._bind_wheel)
        self.canvas.bind("<Leave>", self._unbind_wheel)

    def _sync_region(self, _event=None) -> None:
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        self._toggle_bar()

    def _sync_width(self, event) -> None:
        self.canvas.itemconfigure(self._window, width=event.width)
        self._toggle_bar()

    def _toggle_bar(self) -> None:
        needed = self.inner.winfo_reqheight() > self.canvas.winfo_height() + 2
        if needed and not self._bar_visible:
            self.vbar.grid(row=0, column=1, sticky="ns")
            self._bar_visible = True
        elif not needed and self._bar_visible:
            self.vbar.grid_remove()
            self._bar_visible = False

    def _bind_wheel(self, _event=None) -> None:
        self.canvas.bind_all("<MouseWheel>", self._wheel)

    def _unbind_wheel(self, _event=None) -> None:
        self.canvas.unbind_all("<MouseWheel>")

    def _wheel(self, event) -> None:
        if self.inner.winfo_reqheight() > self.canvas.winfo_height():
            self.canvas.yview_scroll(int(-event.delta / 120), "units")


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------
class EliteApp:
    def __init__(self, root: tk.Tk, initial_file: str | None = None, smoke_test: bool = False):
        self.root = root
        self.smoke_test = smoke_test
        self.settings = self._load_settings()
        self.report: FileReport | None = None
        self.controller: CrackController | None = None
        self._inspect_token = 0
        self._estimate_job = None
        self._poll_job = None
        self._closed = False
        self._last_result: CrackResult | None = None
        self._run_started = 0.0
        self.estimate_for_run: int | None = None

        self.ui_queue: queue.Queue = queue.Queue()

        self._configure_window()
        self._build_style()
        self._build_menu()
        self._build_layout()
        self._bind_shortcuts()

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._poll_job = self.root.after(80, self._poll_ui)

        if initial_file:
            self.root.after(200, lambda: self._load_file(initial_file))
        self.root.after(250, self._maybe_show_notice)

        if smoke_test:
            self.root.after(2200, self.root.destroy)

    # -- setup ----------------------------------------------------------
    def _configure_window(self) -> None:
        self.root.title("ELITE Password Recovery")
        self.root.configure(bg=BG)
        self.root.minsize(940, 650)
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        width = min(1080, max(960, screen_w - 80))
        height = min(760, max(660, screen_h - 110))
        x = max(0, (screen_w - width) // 2)
        y = max(0, (screen_h - height) // 2 - 20)
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        try:
            icon = resource_path("assets/elite.ico")
            if icon.exists():
                self.root.iconbitmap(str(icon))
        except Exception:
            pass

        self.threads = os.cpu_count() or 1
        saved_workers = self.settings.get("workers")
        if not isinstance(saved_workers, int) or not (1 <= saved_workers <= self.threads):
            saved_workers = default_worker_count()

        self.path_var = tk.StringVar(value="")
        self.wordlist_var = tk.StringVar(value=self.settings.get("last_wordlist", ""))
        self.builtin_var = tk.BooleanVar(value=True)
        self.rules_var = tk.StringVar(value=RULE_LABELS[1])
        self.filename_var = tk.BooleanVar(value=True)
        self.workers_var = tk.IntVar(value=saved_workers)
        self.owner_var = tk.BooleanVar(value=False)
        self.lower_var = tk.BooleanVar(value=True)
        self.upper_var = tk.BooleanVar(value=False)
        self.digits_var = tk.BooleanVar(value=True)
        self.symbols_var = tk.BooleanVar(value=False)
        self.space_var = tk.BooleanVar(value=False)
        self.custom_chars_var = tk.StringVar(value="")
        self.brute_min_var = tk.IntVar(value=1)
        self.brute_max_var = tk.IntVar(value=4)
        self.mask_var = tk.StringVar(value="?u?l?l?l?d?d")
        self.mask_sets_var = tk.StringVar(value="")

        self.tried_var = tk.StringVar(value="0")
        self.speed_var = tk.StringVar(value="—")
        self.elapsed_var = tk.StringVar(value="0s")
        self.eta_var = tk.StringVar(value="—")
        self.status_var = tk.StringVar(value="Ready")
        self.percent_var = tk.StringVar(value="")
        self.result_var = tk.StringVar(value="")
        self.result_title_var = tk.StringVar(value="No password recovered yet")
        self.result_hint_var = tk.StringVar(value="Pick a document and a method, then start.")
        self.detail_var = tk.StringVar(value="Choose a password-protected document to begin.")
        self.chip_text = tk.StringVar(value="NO FILE")
        self.chip_fg = MUTED
        self.chip_bg = SURFACE_2

    def _build_style(self) -> None:
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", background=BG, foreground=TEXT, font=(FONT, 10), borderwidth=0)
        style.configure("Card.TFrame", background=SURFACE, borderwidth=0)
        style.configure("Bg.TFrame", background=BG, borderwidth=0)
        style.configure("Card.TLabel", background=SURFACE, foreground=TEXT)
        style.configure("Muted.TLabel", background=SURFACE, foreground=MUTED)

        # Buttons
        style.configure(
            "Accent.TButton",
            background=ACCENT,
            foreground="#04201c",
            font=(FONT, 10, "bold"),
            padding=(12, 10),
            borderwidth=0,
            focusthickness=0,
        )
        style.map(
            "Accent.TButton",
            background=[("pressed", ACCENT_DARK), ("active", ACCENT_HOVER), ("disabled", "#204a45")],
            foreground=[("disabled", "#6f9792")],
        )
        style.configure(
            "Secondary.TButton",
            background=SURFACE_2,
            foreground=TEXT,
            font=(FONT, 9),
            padding=(10, 8),
            borderwidth=0,
            focusthickness=0,
        )
        style.map(
            "Secondary.TButton",
            background=[("pressed", SURFACE_3), ("active", SURFACE_3), ("disabled", SURFACE)],
            foreground=[("disabled", FAINT)],
        )
        style.configure(
            "Ghost.TButton",
            background=SURFACE,
            foreground=MUTED,
            font=(FONT, 9),
            padding=(8, 6),
            borderwidth=0,
            focusthickness=0,
        )
        style.map(
            "Ghost.TButton",
            background=[("active", SURFACE_2), ("pressed", SURFACE_3)],
            foreground=[("active", TEXT)],
        )

        # Entries / comboboxes / spinboxes
        for name in ("Card.TEntry", "Card.TSpinbox", "Card.TCombobox"):
            style.configure(
                name,
                fieldbackground=SURFACE_2,
                background=SURFACE_2,
                foreground=TEXT,
                arrowcolor=MUTED,
                bordercolor=BORDER,
                lightcolor=SURFACE_2,
                darkcolor=SURFACE_2,
                insertcolor=TEXT,
                padding=(7, 6),
            )
        style.map(
            "Card.TEntry",
            bordercolor=[("focus", ACCENT)],
            lightcolor=[("focus", ACCENT)],
            darkcolor=[("focus", ACCENT)],
        )
        style.map(
            "Card.TCombobox",
            fieldbackground=[("readonly", SURFACE_2)],
            foreground=[("readonly", TEXT)],
            bordercolor=[("focus", ACCENT)],
        )
        style.map("Card.TSpinbox", bordercolor=[("focus", ACCENT)])

        # Checkbuttons
        style.configure(
            "Card.TCheckbutton",
            background=SURFACE,
            foreground=TEXT,
            indicatorbackground=SURFACE_2,
            indicatorforeground=ACCENT,
            padding=(0, 2),
            focuscolor=SURFACE,
        )
        style.map(
            "Card.TCheckbutton",
            background=[("active", SURFACE)],
            foreground=[("disabled", FAINT)],
            indicatorbackground=[("selected", ACCENT), ("active", SURFACE_3)],
        )

        # Notebook
        style.configure("Method.TNotebook", background=SURFACE, borderwidth=0, tabmargins=(0, 0, 0, 0))
        style.configure(
            "Method.TNotebook.Tab",
            background=SURFACE,
            foreground=MUTED,
            padding=(16, 8),
            font=(FONT, 9, "bold"),
            borderwidth=0,
        )
        style.map(
            "Method.TNotebook.Tab",
            background=[("selected", SURFACE_2), ("active", SURFACE_2)],
            foreground=[("selected", ACCENT), ("active", TEXT)],
        )

        style.configure(
            "Dark.Vertical.TScrollbar",
            background=SURFACE_3,
            troughcolor=SURFACE,
            bordercolor=BG,
            arrowcolor=MUTED,
            darkcolor=SURFACE_3,
            lightcolor=SURFACE_3,
            width=10,
        )
        style.map(
            "Dark.Vertical.TScrollbar",
            background=[("active", FAINT), ("pressed", MUTED)],
        )

        # Progress
        style.configure(
            "Accent.Horizontal.TProgressbar",
            troughcolor=SURFACE_2,
            background=ACCENT,
            bordercolor=SURFACE_2,
            lightcolor=ACCENT,
            darkcolor=ACCENT,
            thickness=8,
        )

        self.root.option_add("*TCombobox*Listbox.background", SURFACE_2)
        self.root.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.root.option_add("*TCombobox*Listbox.selectBackground", ACCENT)
        self.root.option_add("*TCombobox*Listbox.selectForeground", BG)
        self.root.option_add("*TCombobox*Listbox.font", (FONT, 9))

    def _build_menu(self) -> None:
        menubar = tk.Menu(
            self.root,
            tearoff=0,
            bg=SURFACE_2,
            fg=TEXT,
            activebackground=ACCENT,
            activeforeground=BG,
            bd=0,
            relief="flat",
        )
        file_menu = tk.Menu(
            menubar, tearoff=0, bg=SURFACE_2, fg=TEXT, activebackground=ACCENT, activeforeground=BG
        )
        file_menu.add_command(label="Open document…", accelerator="Ctrl+O", command=self._choose_file)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self._on_close)
        menubar.add_cascade(label="File", menu=file_menu)

        tools_menu = tk.Menu(
            menubar, tearoff=0, bg=SURFACE_2, fg=TEXT, activebackground=ACCENT, activeforeground=BG
        )
        tools_menu.add_command(label="Copy recovered password", command=self._copy_password)
        tools_menu.add_command(label="Clear activity log", command=self._clear_log)
        menubar.add_cascade(label="Tools", menu=tools_menu)

        help_menu = tk.Menu(
            menubar, tearoff=0, bg=SURFACE_2, fg=TEXT, activebackground=ACCENT, activeforeground=BG
        )
        help_menu.add_command(label="How ELITE Password Recovery works", command=self._show_how_it_works)
        help_menu.add_command(label="Legal notice", command=self._show_legal)
        help_menu.add_separator()
        help_menu.add_command(label="About ELITE Password Recovery", command=self._show_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        self.root.configure(menu=menubar)
        self._menubar = menubar

    def _bind_shortcuts(self) -> None:
        self.root.bind("<Control-o>", lambda _e: self._choose_file())
        self.root.bind("<Control-O>", lambda _e: self._choose_file())
        self.root.bind("<F5>", lambda _e: self._start())
        self.root.bind("<Escape>", lambda _e: self._stop())
        self.root.bind("<Control-l>", lambda _e: self._clear_log())

    # -- layout ---------------------------------------------------------
    def _build_layout(self) -> None:
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(1, weight=1)

        self._build_header()
        content = tk.Frame(self.root, bg=BG, padx=18, pady=0)
        content.grid(row=1, column=0, sticky="nsew")
        content.grid_columnconfigure(0, weight=1)
        content.grid_columnconfigure(1, weight=0, minsize=360)
        content.grid_rowconfigure(0, weight=1)

        left = tk.Frame(content, bg=BG)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        left.grid_columnconfigure(0, weight=1)
        left.grid_rowconfigure(1, weight=1)

        right = ScrollColumn(content, width=360)
        right.grid(row=0, column=1, sticky="nsew")

        self._build_file_card(left)
        self._build_method_card(left)
        self._build_options_card(right.inner)
        self._build_progress_card(right.inner)
        self._build_result_card(right.inner)
        self._build_activity_strip()
        self._build_footer()

        self._update_chip()
        self._set_running_ui(False)
        self._update_estimate_soon()

    def _build_header(self) -> None:
        header = tk.Frame(self.root, bg=BG, padx=20, pady=10)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        logo_path = resource_path("assets/logo-64.png")
        try:
            self._logo_image = tk.PhotoImage(file=str(logo_path))
        except Exception:
            self._logo_image = None
        if self._logo_image is not None:
            tk.Label(header, image=self._logo_image, bg=BG).grid(row=0, column=0, rowspan=2, sticky="w")
        else:
            tk.Label(header, text="🔒", bg=BG, fg=ACCENT, font=(FONT, 26)).grid(
                row=0, column=0, rowspan=2, sticky="w", padx=(4, 12)
            )

        title_frame = tk.Frame(header, bg=BG)
        title_frame.grid(row=0, column=1, sticky="w", padx=(12, 0))
        title_row = tk.Frame(title_frame, bg=BG)
        title_row.pack(anchor="w")
        label(
            title_row,
            "ELITE",
            bg=BG,
            fg=TEXT,
            size=23,
            bold=True,
        ).pack(side="left")
        tk.Label(
            title_row,
            text="PASSWORD RECOVERY",
            bg=ACCENT_DARK,
            fg=ACCENT,
            font=(FONT, 8, "bold"),
            padx=7,
            pady=2,
        ).pack(side="left", padx=(9, 0), pady=(7, 0))
        label(
            title_frame,
            "Offline password recovery for PDF, Office, ZIP and 7z documents",
            bg=BG,
            fg=MUTED,
            size=9,
        ).pack(anchor="w", pady=(2, 0))

        chip = tk.Frame(header, bg=SURFACE, padx=11, pady=7)
        chip.grid(row=0, column=2, rowspan=2, sticky="e")
        tk.Label(chip, text="●", bg=SURFACE, fg=GREEN, font=(FONT, 8)).pack(side="left", padx=(0, 5))
        tk.Label(
            chip,
            text="LOCAL PROCESSING",
            bg=SURFACE,
            fg=MUTED,
            font=(FONT, 8, "bold"),
        ).pack(side="left")

    def _build_file_card(self, parent: tk.Frame) -> None:
        card = Card(parent)
        card.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        body = card.body
        body.grid_columnconfigure(1, weight=1)

        label(body, "Target document", size=11, bold=True).grid(
            row=0, column=0, sticky="w", columnspan=2
        )
        self.chip = tk.Label(
            body,
            textvariable=self.chip_text,
            bg=SURFACE_2,
            fg=MUTED,
            font=(FONT, 8, "bold"),
            padx=9,
            pady=3,
        )
        self.chip.grid(row=0, column=2, sticky="e")

        label(body, "File", fg=MUTED, size=9).grid(row=1, column=0, sticky="w", pady=(11, 0))
        self.path_entry = entry(
            body,
            textvariable=self.path_var,
            readonly=True,
            font=(FONT, 9),
        )
        self.path_entry.grid(row=1, column=1, sticky="ew", padx=(10, 8), pady=(10, 0), ipady=4)
        self.browse_btn = ttk.Button(
            body, text="Browse…", style="Secondary.TButton", command=self._choose_file, cursor="hand2"
        )
        self.browse_btn.grid(row=1, column=2, sticky="e", pady=(10, 0))

        self.detail_label = label(
            body, "", fg=MUTED, size=8, anchor="w", justify="left", wraplength=600
        )
        self.detail_label.configure(textvariable=self.detail_var)
        self.detail_label.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(8, 0))

    def _build_method_card(self, parent: tk.Frame) -> None:
        card = Card(parent)
        card.grid(row=1, column=0, sticky="nsew", pady=(0, 12))
        body = card.body
        body.grid_columnconfigure(0, weight=1)
        body.grid_rowconfigure(1, weight=1)

        head = tk.Frame(body, bg=SURFACE)
        head.grid(row=0, column=0, sticky="ew")
        label(head, "Recovery method", size=11, bold=True).pack(side="left")
        label(head, "Start with Dictionary — most people reuse a word.", fg=FAINT, size=8).pack(
            side="right"
        )

        self.notebook = ttk.Notebook(body, style="Method.TNotebook")
        self.notebook.grid(row=1, column=0, sticky="nsew", pady=(9, 0))
        self.notebook.bind("<<NotebookTabChanged>>", lambda _e: self._update_estimate_soon())

        self.dict_tab = self._build_dictionary_tab()
        self.brute_tab = self._build_brute_tab()
        self.mask_tab = self._build_mask_tab()
        self.notebook.add(self.dict_tab, text="Dictionary")
        self.notebook.add(self.brute_tab, text="Brute force")
        self.notebook.add(self.mask_tab, text="Mask")

        bottom = tk.Frame(body, bg=SURFACE)
        bottom.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        bottom.grid_columnconfigure(0, weight=1)
        self.estimate_label = label(bottom, "Search space: —", fg=MUTED, size=8)
        self.estimate_label.grid(row=0, column=0, sticky="w")
        self.estimate_hint = label(bottom, "", fg=FAINT, size=8)
        self.estimate_hint.grid(row=0, column=1, sticky="e")

    def _tab(self) -> ttk.Frame:
        tab = ttk.Frame(self.notebook, style="Card.TFrame", padding=(4, 10, 4, 4))
        tab.grid_columnconfigure(1, weight=1)
        return tab

    def _build_dictionary_tab(self) -> ttk.Frame:
        tab = self._tab()

        label(tab, "Wordlist", fg=MUTED, size=9).grid(row=0, column=0, sticky="w", padx=(4, 10))
        self.wordlist_entry = ttk.Entry(tab, textvariable=self.wordlist_var, style="Card.TEntry")
        self.wordlist_entry.grid(row=0, column=1, sticky="ew", pady=3)
        ttk.Button(
            tab, text="Browse…", style="Secondary.TButton", command=self._choose_wordlist, cursor="hand2"
        ).grid(row=0, column=2, padx=(8, 4))

        ttk.Checkbutton(
            tab,
            text="Use built-in top-10,000 common passwords",
            variable=self.builtin_var,
            style="Card.TCheckbutton",
            command=self._update_estimate_soon,
        ).grid(row=1, column=0, columnspan=2, sticky="w", padx=4, pady=(10, 0))

        self.rules_combo = ttk.Combobox(
            tab,
            textvariable=self.rules_var,
            values=RULE_LABELS,
            state="readonly",
            width=19,
            style="Card.TCombobox",
        )
        self.rules_combo.grid(row=1, column=2, sticky="e", padx=(8, 4), pady=(10, 0))
        self.rules_combo.bind("<<ComboboxSelected>>", lambda _e: self._update_estimate_soon())

        ttk.Checkbutton(
            tab,
            text="Try words from the document filename",
            variable=self.filename_var,
            style="Card.TCheckbutton",
            command=self._update_estimate_soon,
        ).grid(row=2, column=0, columnspan=2, sticky="w", padx=4, pady=(8, 0))
        label(tab, "mutations apply after exact words", fg=FAINT, size=8).grid(
            row=2, column=2, sticky="e", padx=(8, 4), pady=(8, 0)
        )

        self.wordlist_entry.bind("<FocusOut>", lambda _e: self._update_estimate_soon())
        return tab

    def _build_brute_tab(self) -> ttk.Frame:
        tab = self._tab()

        label(tab, "Characters", fg=MUTED, size=9).grid(row=0, column=0, sticky="nw", padx=(4, 10), pady=4)
        charset_frame = tk.Frame(tab, bg=SURFACE)
        charset_frame.grid(row=0, column=1, columnspan=2, sticky="w", pady=2)
        for text, var in [
            ("a-z", self.lower_var),
            ("A-Z", self.upper_var),
            ("0-9", self.digits_var),
            ("Symbols", self.symbols_var),
            ("Space", self.space_var),
        ]:
            ttk.Checkbutton(
                charset_frame,
                text=text,
                variable=var,
                style="Card.TCheckbutton",
                command=self._update_estimate_soon,
            ).pack(side="left", padx=(0, 12))

        label(tab, "Custom", fg=MUTED, size=9).grid(row=1, column=0, sticky="w", padx=(4, 10), pady=4)
        self.custom_chars_entry = ttk.Entry(
            tab, textvariable=self.custom_chars_var, style="Card.TEntry"
        )
        self.custom_chars_entry.grid(row=1, column=1, columnspan=2, sticky="ew", pady=3)
        self.custom_chars_var.trace_add("write", lambda *_a: self._update_estimate_soon())

        label(tab, "Length", fg=MUTED, size=9).grid(row=2, column=0, sticky="w", padx=(4, 10), pady=4)
        length_frame = tk.Frame(tab, bg=SURFACE)
        length_frame.grid(row=2, column=1, columnspan=2, sticky="w", pady=3)
        self.min_spin = ttk.Spinbox(
            length_frame,
            from_=1,
            to=20,
            width=4,
            textvariable=self.brute_min_var,
            style="Card.TSpinbox",
            command=self._update_estimate_soon,
        )
        self.min_spin.pack(side="left")
        self.min_spin.bind("<KeyRelease>", lambda _e: self._update_estimate_soon())
        label(length_frame, "to", fg=MUTED, size=9).pack(side="left", padx=7)
        self.max_spin = ttk.Spinbox(
            length_frame,
            from_=1,
            to=20,
            width=4,
            textvariable=self.brute_max_var,
            style="Card.TSpinbox",
            command=self._update_estimate_soon,
        )
        self.max_spin.pack(side="left")
        self.max_spin.bind("<KeyRelease>", lambda _e: self._update_estimate_soon())
        label(length_frame, "characters", fg=FAINT, size=8).pack(side="left", padx=7)

        return tab

    def _build_mask_tab(self) -> ttk.Frame:
        tab = self._tab()

        label(tab, "Pattern", fg=MUTED, size=9).grid(row=0, column=0, sticky="w", padx=(4, 10))
        self.mask_entry = ttk.Entry(tab, textvariable=self.mask_var, style="Card.TEntry")
        self.mask_entry.grid(row=0, column=1, sticky="ew", pady=3)
        self.mask_var.trace_add("write", lambda *_a: self._update_estimate_soon())

        label(tab, "Custom sets", fg=MUTED, size=9).grid(row=1, column=0, sticky="w", padx=(4, 10), pady=4)
        self.mask_sets_entry = ttk.Entry(tab, textvariable=self.mask_sets_var, style="Card.TEntry")
        self.mask_sets_entry.grid(row=1, column=1, sticky="ew", pady=3)
        self.mask_sets_var.trace_add("write", lambda *_a: self._update_estimate_soon())

        help_text = (
            "?l a-z   ?u A-Z   ?d 0-9   ?s symbols   ?a all   ?h hex   "
            "?1–?9 custom   ?? literal ?\n"
            "Example: ?u?l?l?l?d?d   ·   custom sets: 1=abc;2=XYZ"
        )
        label(
            tab,
            help_text,
            fg=FAINT,
            size=8,
            font=MONO,
            justify="left",
            anchor="w",
        ).grid(row=2, column=0, columnspan=2, sticky="w", padx=4, pady=(10, 0))

        return tab

    def _build_options_card(self, parent: tk.Frame) -> None:
        card = Card(parent)
        card.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        body = card.body
        body.grid_columnconfigure(1, weight=1)

        label(body, "Run options", size=11, bold=True).grid(row=0, column=0, columnspan=2, sticky="w")

        label(body, "CPU threads", fg=MUTED, size=9).grid(row=1, column=0, sticky="w", pady=(12, 0))
        workers_frame = tk.Frame(body, bg=SURFACE)
        workers_frame.grid(row=1, column=1, sticky="e", pady=(12, 0))
        self.workers_spin = ttk.Spinbox(
            workers_frame,
            from_=1,
            to=self.threads,
            width=4,
            textvariable=self.workers_var,
            style="Card.TSpinbox",
            command=self._save_workers,
        )
        self.workers_spin.pack(side="left")
        label(workers_frame, f"of {self.threads}", fg=FAINT, size=8).pack(side="left", padx=(6, 0))

        self.owner_check = ttk.Checkbutton(
            body,
            text="Also test PDF owner password  (slower)",
            variable=self.owner_var,
            style="Card.TCheckbutton",
        )
        self.owner_check.grid(row=2, column=0, columnspan=2, sticky="w", pady=(10, 0))

        buttons = tk.Frame(body, bg=SURFACE)
        buttons.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(14, 0))
        buttons.grid_columnconfigure(0, weight=1)
        self.start_btn = ttk.Button(
            buttons, text="Start recovery", style="Accent.TButton", command=self._start, cursor="hand2"
        )
        self.start_btn.grid(row=0, column=0, sticky="ew")
        self.stop_btn = ttk.Button(
            buttons, text="Stop", style="Secondary.TButton", command=self._stop, cursor="hand2"
        )
        self.stop_btn.grid(row=0, column=1, sticky="e", padx=(8, 0))

    def _build_progress_card(self, parent: tk.Frame) -> None:
        card = Card(parent)
        card.grid(row=1, column=0, sticky="ew", pady=(0, 12))
        body = card.body
        body.grid_columnconfigure(0, weight=1)

        head = tk.Frame(body, bg=SURFACE)
        head.grid(row=0, column=0, sticky="ew")
        label(head, "Progress", size=11, bold=True).pack(side="left")
        label(head, "", fg=ACCENT, size=10, bold=True, textvariable=self.percent_var).pack(side="right")

        self.status_label = label(body, "", fg=MUTED, size=9, anchor="w")
        self.status_label.configure(textvariable=self.status_var)
        self.status_label.grid(row=1, column=0, sticky="ew", pady=(8, 7))

        self.progress = ttk.Progressbar(
            body, style="Accent.Horizontal.TProgressbar", mode="determinate", maximum=100, value=0
        )
        self.progress.grid(row=2, column=0, sticky="ew")

        stats = tk.Frame(body, bg=SURFACE)
        stats.grid(row=3, column=0, sticky="ew", pady=(13, 0))
        for col in range(4):
            stats.grid_columnconfigure(col, weight=1)
        self._stat(stats, "Tried", self.tried_var, 0)
        self._stat(stats, "Speed", self.speed_var, 1)
        self._stat(stats, "Elapsed", self.elapsed_var, 2)
        self._stat(stats, "ETA", self.eta_var, 3)

    def _stat(self, parent: tk.Frame, title: str, var: tk.StringVar, col: int) -> None:
        frame = tk.Frame(parent, bg=SURFACE)
        frame.grid(row=0, column=col, sticky="w", padx=(0, 4))
        label(frame, title.upper(), fg=FAINT, size=7, bold=True).pack(anchor="w")
        tk.Label(
            frame,
            textvariable=var,
            bg=SURFACE,
            fg=TEXT,
            font=(MONO, 10, "bold"),
        ).pack(anchor="w")

    def _build_result_card(self, parent: tk.Frame) -> None:
        card = Card(parent)
        card.grid(row=2, column=0, sticky="ew", pady=(0, 12))
        body = card.body
        body.grid_columnconfigure(0, weight=1)

        label(body, "Recovered password", size=11, bold=True).grid(row=0, column=0, sticky="w")
        self.result_title = label(body, "", fg=MUTED, size=9, anchor="w")
        self.result_title.configure(textvariable=self.result_title_var)
        self.result_title.grid(row=1, column=0, sticky="ew", pady=(8, 5))

        row = tk.Frame(body, bg=SURFACE)
        row.grid(row=2, column=0, sticky="ew")
        row.grid_columnconfigure(0, weight=1)
        self.result_entry = entry(
            row,
            textvariable=self.result_var,
            readonly=True,
            fg=GREEN,
            font=(MONO, 13, "bold"),
        )
        self.result_entry.grid(row=0, column=0, sticky="ew", ipady=4)
        self.copy_btn = ttk.Button(
            row, text="Copy", style="Secondary.TButton", command=self._copy_password, cursor="hand2"
        )
        self.copy_btn.grid(row=0, column=1, padx=(8, 0))
        self.copy_btn.state(["disabled"])

        self.result_hint = label(body, "", fg=FAINT, size=8, anchor="w", wraplength=320, justify="left")
        self.result_hint.configure(textvariable=self.result_hint_var)
        self.result_hint.grid(row=3, column=0, sticky="ew", pady=(7, 0))

    def _build_activity_strip(self) -> None:
        outer = tk.Frame(self.root, bg=BG, padx=18, pady=2)
        outer.grid(row=2, column=0, sticky="ew")
        border = tk.Frame(outer, bg=BORDER)
        border.pack(fill="x")
        inner = tk.Frame(border, bg=SURFACE_2, padx=10, pady=5)
        inner.pack(fill="both", expand=True, padx=1, pady=1)
        inner.grid_columnconfigure(1, weight=1)

        label(
            inner,
            "ACTIVITY",
            bg=SURFACE_2,
            fg=FAINT,
            size=7,
            bold=True,
        ).grid(row=0, column=0, sticky="nw", pady=(3, 0))
        self.log_text = tk.Text(
            inner,
            height=2,
            bg=SURFACE_2,
            fg=MUTED,
            insertbackground=TEXT,
            relief="flat",
            bd=0,
            highlightthickness=0,
            wrap="word",
            font=(MONO, 8),
            padx=2,
            pady=1,
            state="disabled",
        )
        self.log_text.grid(row=0, column=1, sticky="ew", padx=(10, 8))
        ttk.Button(
            inner, text="Clear", style="Ghost.TButton", command=self._clear_log, cursor="hand2"
        ).grid(row=0, column=2, sticky="ne")

    def _build_footer(self) -> None:
        footer = tk.Frame(self.root, bg=BG, padx=20, pady=8)
        footer.grid(row=3, column=0, sticky="ew")
        footer.grid_columnconfigure(0, weight=1)
        label(
            footer,
            "Use only on documents you own or are authorized to access.",
            bg=BG,
            fg=FAINT,
            size=8,
        ).grid(row=0, column=0, sticky="w")
        label(
            footer,
            f"v{__version__}  ·  local only",
            bg=BG,
            fg=FAINT,
            size=8,
        ).grid(row=0, column=1, sticky="e")

    # -- state helpers --------------------------------------------------
    @property
    def current_mode(self) -> int:
        try:
            return self.notebook.index(self.notebook.select())
        except Exception:
            return MODE_DICTIONARY

    def _set_running_ui(self, running: bool) -> None:
        if running:
            self.start_btn.state(["disabled"])
            self.stop_btn.state(["!disabled"])
            self.browse_btn.state(["disabled"])
            self.workers_spin.state(["disabled"])
            self.owner_check.state(["disabled"])
        else:
            can_start = bool(self.report and self.report.supported and self.report.encrypted)
            self.start_btn.state(["!disabled"] if can_start else ["disabled"])
            self.stop_btn.state(["disabled"])
            self.browse_btn.state(["!disabled"])
            self.workers_spin.state(["!disabled"])
            can_owner = bool(self.report and self.report.kind == "pdf" and self.report.supported)
            self.owner_check.state(["!disabled"] if can_owner else ["disabled"])
            if not can_owner:
                self.owner_var.set(False)

    def _update_chip(self) -> None:
        if not hasattr(self, "chip"):
            return
        self.chip.configure(text=self.chip_text.get(), fg=self.chip_fg, bg=self.chip_bg)

    def _chip(self, text: str, fg: str, bg: str) -> None:
        self.chip_text.set(text)
        self.chip_fg = fg
        self.chip_bg = bg
        self._update_chip()

    def _status(self, text: str, color: str = MUTED) -> None:
        self.status_var.set(text)
        self.status_label.configure(fg=color)

    # -- file handling --------------------------------------------------
    def _choose_file(self) -> None:
        if self.controller and self.controller.running:
            return
        last_dir = self.settings.get("last_dir") or str(Path.home())
        path = filedialog.askopenfilename(
            parent=self.root,
            title="Open a password-protected document",
            initialdir=last_dir,
            filetypes=[
                ("Protected documents", "*.pdf *.docx *.xlsx *.pptx *.doc *.xls *.ppt *.zip *.7z"),
                ("PDF", "*.pdf"),
                ("Office", "*.docx *.xlsx *.pptx *.doc *.xls *.ppt"),
                ("Archives", "*.zip *.7z"),
                ("All files", "*.*"),
            ],
        )
        if path:
            self._load_file(path)

    def _load_file(self, path: str) -> None:
        path_obj = Path(path)
        self.path_var.set(str(path_obj))
        self.detail_var.set("Inspecting encryption…")
        self.report = None
        self._chip("CHECKING", MUTED, SURFACE_2)
        self._status("Reading document header…", MUTED)
        self.start_btn.state(["disabled"])
        self.settings["last_dir"] = str(path_obj.parent)
        self._save_settings()
        self._inspect_token += 1
        token = self._inspect_token

        def work() -> None:
            report = inspect_file(path_obj)
            self.ui_queue.put(("inspect", token, report))

        threading.Thread(target=work, daemon=True).start()
        self._log(f"Inspecting {path_obj.name}")

    def _apply_report(self, report: FileReport) -> None:
        self.report = report
        self.root.title(f"ELITE Password Recovery — {report.path.name}")
        size = human_size(report.size)
        if not report.supported:
            self._chip("UNSUPPORTED", RED, RED_DARK)
            self.detail_var.set(report.note)
            self._status("Unsupported file", RED)
            self._log(f"Unsupported: {report.note}")
            self.start_btn.state(["disabled"])
            self._set_running_ui(False)
        elif not report.encrypted:
            self._chip("NOT ENCRYPTED", AMBER, AMBER_DARK)
            self.detail_var.set(f"{report.note}  ·  {size}")
            self._status("No password required", AMBER)
            self._log("This document is not password protected.")
            self.start_btn.state(["disabled"])
            self._set_running_ui(False)
        else:
            self._chip(report.label.upper(), ACCENT, ACCENT_DARK)
            self.detail_var.set(f"{report.label}  ·  {size}")
            self._status("Ready to recover", MUTED)
            self._log(f"Detected {report.label} · {size}")
            self._set_running_ui(False)
        self._update_estimate_soon()

    def _choose_wordlist(self) -> None:
        last_dir = self.settings.get("last_wordlist_dir") or str(Path.home())
        path = filedialog.askopenfilename(
            parent=self.root,
            title="Choose a wordlist",
            initialdir=last_dir,
            filetypes=[("Text files", "*.txt *.lst *.dic *.wordlist"), ("All files", "*.*")],
        )
        if path:
            self.wordlist_var.set(path)
            self.settings["last_wordlist_dir"] = str(Path(path).parent)
            self._save_settings()
            self._update_estimate_soon()

    # -- plan / estimate ------------------------------------------------
    def _build_plan(self) -> CandidatePlan:
        mode = self.current_mode
        if mode == MODE_DICTIONARY:
            lists: list[str] = []
            if self.builtin_var.get():
                builtin = resource_path("wordlists/common-passwords.txt")
                if builtin.is_file():
                    lists.append(str(builtin))
            custom = self.wordlist_var.get().strip().strip('"')
            if custom:
                if not Path(custom).is_file():
                    raise ValueError("The selected wordlist does not exist.")
                lists.append(custom)
            if not lists:
                raise ValueError("Choose a wordlist or enable the built-in common-password list.")
            rules = RULE_KEYS[max(0, min(2, RULE_LABELS.index(self.rules_var.get())))]
            filename = self.report.path.name if self.report else ""
            return DictionaryPlan(
                wordlists=lists,
                rules=rules,
                include_filename=self.filename_var.get(),
                filename=filename,
            )

        if mode == MODE_BRUTE:
            chars = []
            if self.lower_var.get():
                chars.append("abcdefghijklmnopqrstuvwxyz")
            if self.upper_var.get():
                chars.append("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
            if self.digits_var.get():
                chars.append("0123456789")
            if self.symbols_var.get():
                chars.append("!@#$%^&*()-_=+[]{};:'\",.<>/?\\|~`")
            if self.space_var.get():
                chars.append(" ")
            custom = self.custom_chars_var.get()
            if custom:
                chars.append(custom)
            alphabet = "".join(dict.fromkeys("".join(chars)))
            if not alphabet:
                raise ValueError("Select at least one character set or enter custom characters.")
            try:
                min_len = int(self.brute_min_var.get())
                max_len = int(self.brute_max_var.get())
            except (ValueError, tk.TclError):
                raise ValueError("Lengths must be whole numbers.")
            if min_len < 1 or max_len < min_len:
                raise ValueError("Length range is invalid (minimum 1, maximum ≥ minimum).")
            if max_len > 20:
                raise ValueError("Maximum length is capped at 20 characters.")
            return BrutePlan(chars=alphabet, min_length=min_len, max_length=max_len)

        pattern = self.mask_var.get().strip()
        custom_sets = parse_custom_sets(self.mask_sets_var.get())
        plan = MaskPlan(pattern=pattern, custom_sets=custom_sets)
        plan.groups()  # validate now, so the estimate label can show errors
        return plan

    def _update_estimate_soon(self) -> None:
        if self._estimate_job is not None:
            try:
                self.root.after_cancel(self._estimate_job)
            except Exception:
                pass
        self._estimate_job = self.root.after(350, self._update_estimate)

    def _update_estimate(self) -> None:
        self._estimate_job = None
        if not self.report or not self.report.supported or not self.report.encrypted:
            self.estimate_label.configure(text="Search space: —", fg=MUTED)
            self.estimate_hint.configure(text="")
            return
        try:
            plan = self._build_plan()
            estimate = plan.estimate()
        except Exception as exc:
            self.estimate_label.configure(text=f"⚠ {exc}", fg=RED)
            self.estimate_hint.configure(text="")
            return
        if estimate is None:
            self.estimate_label.configure(text="Search space: unknown", fg=MUTED)
            self.estimate_hint.configure(text="")
            return
        if estimate == 0:
            self.estimate_label.configure(text="Search space: 0 candidates", fg=RED)
            self.estimate_hint.configure(text="")
            return
        approx = "~" if self.current_mode == MODE_DICTIONARY else ""
        self.estimate_label.configure(
            text=f"Search space: {approx}{human_count(estimate)} candidates", fg=MUTED
        )
        if estimate >= 1_000_000_000:
            self.estimate_hint.configure(text="very large", fg=AMBER)
        elif estimate >= 50_000_000:
            self.estimate_hint.configure(text="large", fg=AMBER)
        else:
            self.estimate_hint.configure(text="", fg=FAINT)

    # -- run ------------------------------------------------------------
    def _start(self) -> None:
        if self.controller and self.controller.running:
            return
        if not self.report or not self.report.supported:
            messagebox.showwarning(
                "No supported document",
                "Choose a supported, password-protected document first.",
                parent=self.root,
            )
            return
        if not self.report.encrypted:
            messagebox.showinfo(
                "No password needed",
                "This document is not password protected.",
                parent=self.root,
            )
            return
        try:
            plan = self._build_plan()
            estimate = plan.estimate()
        except Exception as exc:
            messagebox.showerror("Cannot start", str(exc), parent=self.root)
            return
        if not estimate:
            messagebox.showerror("Nothing to test", "The selected method produces no candidates.", parent=self.root)
            return
        if estimate > 50_000_000:
            extra = ""
            if "agile" in self.report.label.lower():
                extra = "\n\nThis Office file uses slow Agile encryption (roughly 20–100 checks/sec)."
            if not messagebox.askyesno(
                "Large search space",
                f"This run has about {human_count(estimate)} candidates and may take a very long time."
                f"{extra}\n\nStart anyway?",
                parent=self.root,
            ):
                return

        self._last_result = None
        self.estimate_for_run = estimate
        self.result_var.set("")
        self.result_title.configure(fg=MUTED)
        self.result_title_var.set("Testing candidates…")
        self.result_hint_var.set("The recovered password will appear here.")
        self.copy_btn.state(["disabled"])
        self.tried_var.set("0")
        self.speed_var.set("—")
        self.elapsed_var.set("0s")
        self.eta_var.set("—")
        self.percent_var.set("")
        self.progress.stop()
        self.progress.configure(mode="determinate", maximum=100, value=0)
        self._status("Starting workers…", ACCENT)
        self._run_started = time.monotonic()
        self._set_running_ui(True)

        try:
            requested_workers = int(self.workers_var.get())
        except (ValueError, tk.TclError):
            requested_workers = default_worker_count()
        workers = max(1, min(self.threads, requested_workers))
        self.workers_var.set(workers)
        batch = recommended_batch_size(self.report.label)
        try_owner = bool(self.owner_var.get() and self.report.kind == "pdf")

        self._log(
            f"Starting {plan.describe()} · {workers} threads · ~{human_count(estimate)} candidates"
        )
        self._log(f"Target: {self.report.path.name} ({self.report.label})")

        self.controller = CrackController(
            path=self.report.path,
            plan=plan,
            workers=workers,
            try_owner=try_owner,
            batch_size=batch,
            estimate=estimate,
            on_progress=lambda snapshot: self.ui_queue.put(("progress", snapshot)),
            on_done=lambda result: self.ui_queue.put(("done", result)),
            on_log=lambda message: self.ui_queue.put(("log", message)),
        )
        self.controller.start()
        self.root.after(50, self._poll_controller_start)

    def _poll_controller_start(self) -> None:
        if self.controller and self.controller.running:
            self._status("Cracking…", ACCENT)

    def _stop(self) -> None:
        if not self.controller or not self.controller.running:
            return
        self._status("Stopping…", AMBER)
        self.stop_btn.state(["disabled"])
        self.controller.stop()
        self._log("Stop requested.")

    def _apply_progress(self, snapshot: ProgressSnapshot) -> None:
        self.tried_var.set(f"{snapshot.tried:,}")
        self.speed_var.set(human_speed(snapshot.speed))
        self.elapsed_var.set(human_duration(snapshot.elapsed))
        self.eta_var.set(human_duration(snapshot.eta) if snapshot.percent is not None else "—")
        if snapshot.percent is not None:
            self.progress.configure(mode="determinate", value=min(100.0, snapshot.percent * 100))
            self.percent_var.set(f"{snapshot.percent * 100:.1f}%")
        else:
            self.percent_var.set("")

    def _apply_done(self, result: CrackResult) -> None:
        self._last_result = result
        self._set_running_ui(False)
        self.progress.stop()
        if result.reason in ("found", "exhausted"):
            percent = 1.0
        elif self.estimate_for_run:
            percent = min(1.0, result.tried / self.estimate_for_run)
        else:
            percent = None
        self._apply_progress(
            ProgressSnapshot(
                tried=result.tried,
                elapsed=result.elapsed,
                speed=result.tried / result.elapsed if result.elapsed else 0,
                eta=0 if result.reason in ("found", "exhausted") else None,
                percent=percent,
                estimate=self.estimate_for_run,
            )
        )
        if result.found:
            self.progress.configure(mode="determinate", value=100)
            self.percent_var.set("100%")
            self.result_var.set(result.password or "")
            self.result_title.configure(fg=GREEN)
            self.result_title_var.set("✓ Password found")
            self.result_hint_var.set(
                f"Recovered after {result.tried:,} attempts in {human_duration(result.elapsed)}. "
                "Copy it and open the document normally."
            )
            self.copy_btn.state(["!disabled"])
            self._status("Password recovered", GREEN)
            self._log(f"PASSWORD FOUND: {result.password!r} ({result.tried:,} tries)")
            try:
                self.root.bell()
            except Exception:
                pass
        elif result.reason == "stopped":
            self.result_title.configure(fg=AMBER)
            self.result_title_var.set("Stopped")
            self.result_hint_var.set("The search was stopped before a password was found.")
            self._status("Stopped", AMBER)
            self._log(f"Stopped after {result.tried:,} attempts.")
        elif result.reason == "error":
            self.result_title.configure(fg=RED)
            self.result_title_var.set("Recovery error")
            self.result_hint_var.set(result.error or "An unknown error occurred.")
            self._status("Error", RED)
            self._log(f"ERROR: {result.error}")
        else:
            self.result_title.configure(fg=AMBER)
            self.result_title_var.set("Password not found")
            self.result_hint_var.set(
                "Try a different wordlist, add mutations, or use a mask/brute-force search."
            )
            self._status("No match in the tested candidates", AMBER)
            self._log(f"Exhausted {result.tried:,} candidates without a match.")

    # -- UI queue -------------------------------------------------------
    def _poll_ui(self) -> None:
        if self._closed:
            return
        try:
            while True:
                item = self.ui_queue.get_nowait()
                kind = item[0]
                if kind == "progress":
                    self._apply_progress(item[1])
                elif kind == "done":
                    self._apply_done(item[1])
                elif kind == "inspect":
                    token, report = item[1], item[2]
                    if token == self._inspect_token:
                        self._apply_report(report)
                elif kind == "log":
                    self._log(item[1])
        except queue.Empty:
            pass
        except Exception:
            pass
        self._poll_job = self.root.after(80, self._poll_ui)

    # -- utilities ------------------------------------------------------
    def _log(self, message: str) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.configure(state="normal")
        self.log_text.insert("end", f"[{timestamp}] {message}\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _clear_log(self) -> None:
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _copy_password(self) -> None:
        value = self.result_var.get()
        if not value:
            return
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(value)
            self.root.update_idletasks()
            self.result_hint_var.set("Copied to clipboard.")
        except Exception:
            self.result_hint_var.set("Could not access the clipboard.")

    def _save_workers(self) -> None:
        try:
            workers = int(self.workers_var.get())
        except Exception:
            return
        self.settings["workers"] = workers
        self._save_settings()

    def _load_settings(self) -> dict:
        try:
            return json.loads(settings_path().read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_settings(self) -> None:
        try:
            settings_path().write_text(json.dumps(self.settings, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _on_close(self) -> None:
        if self.controller and self.controller.running:
            if not messagebox.askyesno(
                "Recovery is running",
                "Stop the current recovery and exit ELITE Password Recovery?",
                parent=self.root,
            ):
                return
            self.controller.stop()
            self.controller.join(timeout=1.5)
        self._closed = True
        try:
            self.settings["workers"] = int(self.workers_var.get())
        except Exception:
            pass
        self._save_settings()
        if self._poll_job:
            try:
                self.root.after_cancel(self._poll_job)
            except Exception:
                pass
        self.root.destroy()

    # -- dialogs --------------------------------------------------------
    def _center_dialog(self, dialog: tk.Toplevel, width: int, height: int) -> None:
        self.root.update_idletasks()
        x = self.root.winfo_rootx() + max(0, (self.root.winfo_width() - width) // 2)
        y = self.root.winfo_rooty() + max(0, (self.root.winfo_height() - height) // 2)
        dialog.geometry(f"{width}x{height}+{x}+{y}")

    def _maybe_show_notice(self) -> None:
        if os.environ.get("ELITE_SKIP_NOTICE") == "1":
            return
        if self.settings.get("notice_accepted"):
            return
        self._show_notice()

    def _show_notice(self) -> None:
        dialog = tk.Toplevel(self.root)
        dialog.title("Before you begin")
        dialog.configure(bg=BG)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()
        self._center_dialog(dialog, 620, 470)

        header = tk.Frame(dialog, bg=BG, padx=22, pady=18)
        header.pack(fill="x")
        label(header, "Before you begin", bg=BG, fg=TEXT, size=17, bold=True).pack(anchor="w")
        label(
            header,
            "ELITE Password Recovery is a recovery tool, not an unlocking service.",
            bg=BG,
            fg=MUTED,
            size=9,
        ).pack(anchor="w", pady=(4, 0))

        card = Card(dialog)
        card.pack(fill="both", expand=True, padx=22, pady=10)
        body = card.body
        body.grid_columnconfigure(0, weight=1)

        text = (
            "Use ELITE Password Recovery only on documents that you own or that you have explicit "
            "permission to access. Trying to open someone else's protected files may be "
            "illegal and can have serious consequences.\n\n"
            "Everything runs locally on this PC. No document, password or wordlist is "
            "uploaded anywhere.\n\n"
            "A recovery can take seconds or days depending on the password and method. "
            "There is no guarantee that a password will be found."
        )
        tk.Message(
            body,
            text=text,
            bg=SURFACE,
            fg=MUTED,
            font=(FONT, 10),
            width=520,
            justify="left",
        ).grid(row=0, column=0, sticky="nw")

        actions = tk.Frame(dialog, bg=BG, padx=22, pady=16)
        actions.pack(fill="x")
        ttk.Button(
            actions,
            text="Exit",
            style="Secondary.TButton",
            command=self.root.destroy,
            cursor="hand2",
        ).pack(side="right")
        accept = ttk.Button(
            actions,
            text="I understand — continue",
            style="Accent.TButton",
            cursor="hand2",
        )
        accept.pack(side="right", padx=(0, 8))

        def proceed() -> None:
            self.settings["notice_accepted"] = True
            self._save_settings()
            dialog.grab_release()
            dialog.destroy()
            self.root.focus_force()

        accept.configure(command=proceed)
        dialog.protocol("WM_DELETE_WINDOW", self.root.destroy)

    def _show_text_dialog(self, title: str, heading: str, body_text: str, width: int = 640, height: int = 470) -> None:
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.configure(bg=BG)
        dialog.transient(self.root)
        dialog.grab_set()
        self._center_dialog(dialog, width, height)

        header = tk.Frame(dialog, bg=BG, padx=22, pady=18)
        header.pack(fill="x")
        label(header, heading, bg=BG, fg=TEXT, size=17, bold=True).pack(anchor="w")

        card = Card(dialog)
        card.pack(fill="both", expand=True, padx=22, pady=10)
        card.body.grid_rowconfigure(0, weight=1)
        text = tk.Text(
            card.body,
            bg=SURFACE,
            fg=MUTED,
            relief="flat",
            bd=0,
            highlightthickness=0,
            wrap="word",
            font=(FONT, 10),
            padx=2,
            pady=2,
            height=10,
        )
        text.grid(row=0, column=0, sticky="nsew")
        text.insert("1.0", body_text)
        text.configure(state="disabled")

        actions = tk.Frame(dialog, bg=BG, padx=22, pady=16)
        actions.pack(fill="x")
        ttk.Button(
            actions, text="Close", style="Accent.TButton", command=dialog.destroy, cursor="hand2"
        ).pack(side="right")
        dialog.protocol("WM_DELETE_WINDOW", dialog.destroy)

    def _show_how_it_works(self) -> None:
        self._show_text_dialog(
            "How ELITE Password Recovery works",
            "How ELITE Password Recovery works",
            "ELITE Password Recovery tries candidate passwords against the document's real "
            "encryption check. It does not remove or bypass encryption, and it "
            "never alters the original file.\n\n"
            "DICTIONARY\n"
            "Tests every line of a wordlist. Light mutations add common case "
            "changes, a trailing digit and popular suffixes. Medium mutations "
            "add leetspeak, years, reversed words and two-digit suffixes.\n\n"
            "BRUTE FORCE\n"
            "Tries every combination of the selected characters. Each extra "
            "character multiplies the work, so keep the maximum length small.\n\n"
            "MASK\n"
            "Uses placeholders to describe a pattern. ?l = a-z, ?u = A-Z, "
            "?d = 0-9, ?s = symbols, ?a = printable, ?h = hex. Define your own "
            "sets with 1=abc;2=XYZ and use ?1, ?2.\n\n"
            "SPEED\n"
            "PDF and ZIP are usually fast. Office Agile encryption is "
            "deliberately expensive and may only reach tens of attempts per "
            "second. More CPU threads help, up to the number of cores.\n\n"
            "TIPS\n"
            "Start with a personal wordlist (names, dates, old passwords). "
            "Try exact words first, then Light mutations. Use the filename "
            "option for documents named after their subject.",
        )

    def _show_legal(self) -> None:
        self._show_text_dialog(
            "Legal notice",
            "Authorized use only",
            "ELITE Password Recovery is intended for recovering access to documents that you "
            "own or are explicitly authorized to access, such as your own "
            "forgotten files or a customer's file with their permission.\n\n"
            "Accessing a protected document without authorization may violate "
            "computer-misuse, privacy and data-protection laws in your country. "
            "You are solely responsible for how you use this software.\n\n"
            "The software is provided as-is, without warranty of any kind. "
            "Password recovery is not guaranteed; strong, unique passwords may "
            "take an infeasible amount of time to find.\n\n"
            "All processing is local. No files, passwords or usage data are sent "
            "to the author or any third party.",
        )

    def _show_about(self) -> None:
        self._show_text_dialog(
            "About ELITE Password Recovery",
            "ELITE Password Recovery",
            f"Version {__version__}\n\n"
            "A local, offline password-recovery tool for PDF, Microsoft Office, "
            "ZIP and 7z documents.\n\n"
            "Built with Python, Tkinter, pypdf, msoffcrypto-tool, pyzipper, "
            "py7zr and PyCryptodome.\n\n"
            "The built-in wordlist is the Pwdb Top 10,000 list from SecLists "
            "(MIT licensed).\n\n"
            "Use only on documents you own or are authorized to access.",
        )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def enable_dpi_awareness() -> None:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def enable_dark_title_bar(root: tk.Tk) -> None:
    """Ask DWM for a dark caption on Windows 10/11."""
    try:
        root.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        if not hwnd:
            hwnd = root.winfo_id()
        enabled = ctypes.c_int(1)
        for attribute in (20, 19):
            result = ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, attribute, ctypes.byref(enabled), ctypes.sizeof(enabled)
            )
            if result == 0:
                break
    except Exception:
        pass


def run(initial_file: str | None = None, smoke_test: bool = False) -> None:
    enable_dpi_awareness()
    root = tk.Tk()
    try:
        root.tk.call("tk", "scaling", root.winfo_fpixels("1i") / 72.0)
    except Exception:
        pass
    EliteApp(root, initial_file=initial_file, smoke_test=smoke_test)
    enable_dark_title_bar(root)
    root.mainloop()
